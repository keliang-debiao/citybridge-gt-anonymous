import copy
import csv
import json
import tempfile
import unittest
from pathlib import Path

import numpy as np
import torch

from citybridge.data import (read_events, enumerate_instances, split_instances,
                             fit_training, build_assets, prepare, haversine)
from citybridge.demo import make_toy, demo_config
from citybridge.engine import read, load_training
from citybridge.metrics import ranks, ranking_metrics, temperature_fit, calibration
from citybridge.model import CityBridge, sample_loss, bridge_loss
from citybridge.statistics import holm, aggregate, paired_inference
from citybridge.convert import inside_geometry
from citybridge.experiments import perturb_assets
from citybridge.util import config, seed_all, digest


class CoreTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        seed_all(19)
        cls.tmp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.tmp.name)
        cls.cfg = demo_config(config(Path(__file__).resolve().parents[1]/'configs/paper.yaml'))
        make_toy(cls.root/'raw')
        cls.events, _ = read_events(cls.root/'raw'/'NYC.csv')
        cls.samples = enumerate_instances(cls.events, 12, 12)
        cls.splits = split_instances(cls.samples, 1)
        cls.train = fit_training(cls.splits['train'], 2)
        cls.assets = build_assets(cls.train, cls.splits['train'], cls.cfg['preprocessing'])
        cls.assets.update(domain='NYC', fold=1, synthetic=True)
        for city in ['NYC', 'TKY', 'CA']:
            prepare(cls.root/'raw'/f'{city}.csv', cls.root/'prepared'/city/'fold1', 1,
                    cls.cfg['preprocessing'], city, True)
        cls.by_city = {c: read(cls.root/'prepared'/c/'fold1'/'assets.json') for c in ['NYC','TKY','CA']}
        cls.sample = read(cls.root/'prepared'/'NYC'/'fold1'/'train.json')[5]

    @classmethod
    def tearDownClass(cls): cls.tmp.cleanup()

    def model(self):
        seed_all(23)
        return CityBridge(self.by_city, self.cfg['model'])

    def test_fold_target_disjoint(self):
        for f in range(1, 6):
            x = split_instances(self.samples, f)
            ids = {k: {s['target']['id'] for s in v} for k, v in x.items()}
            for a,b in [('train','val'),('train','test'),('val','test')]:
                self.assertFalse(ids[a] & ids[b])

    def test_each_target_tested_at_most_once(self):
        seen = set()
        for f in range(1,6):
            test = {s['target']['id'] for s in split_instances(self.samples, f)['test']}
            self.assertFalse(seen & test); seen |= test

    def test_prefixes_strictly_causal(self):
        for s in self.samples:
            self.assertTrue(all(e['t'] < s['target']['t'] for e in s['prefix']))
            self.assertLessEqual(len(s['prefix']), 12)

    def test_graph_fits_no_future_features(self):
        raw = copy.deepcopy(self.splits)
        for s in raw['test']:
            s['target']['lat'] = -50; s['target']['cat'] = 'future_secret'
        tr = fit_training(raw['train'], 2)
        a = build_assets(tr, raw['train'], self.cfg['preprocessing'])
        self.assertEqual(a['features'], self.assets['features'])
        self.assertEqual(a['edges'], self.assets['edges'])

    def test_training_transition_event_provenance(self):
        ids = set(self.assets['train_event_ids'])
        for a,b in self.assets['transition_event_pairs']:
            self.assertIn(a, ids); self.assertIn(b, ids)

    def test_transition_counts_are_not_prefix_multiplied(self):
        counts = sum(t[2] for t in self.assets['transitions'])
        self.assertEqual(counts, len(self.assets['transition_event_pairs']))

    def test_transition_descriptor_has_34_dimensions(self):
        for e in self.assets['edges']:
            self.assertEqual(len(e[4]), 34)
            if e[2] == 0:
                self.assertAlmostEqual(sum(e[4][3:27]), 1.)
                self.assertAlmostEqual(sum(e[4][27:]), 1.)

    def test_category_free_disables_semantic_graph(self):
        a = self.by_city['CA']
        self.assertFalse(any(a['categories']))
        self.assertFalse(any(e[2] == 3 for e in a['edges']))

    def test_forward_shape_and_finite_gradients(self):
        model = self.model()
        r = model('NYC', self.sample)
        self.assertEqual(r['logits'].shape, (len(self.assets['pois']),))
        loss = sample_loss(model, 'NYC', self.sample, r, self.cfg['loss'])+bridge_loss(model, 8)
        loss.backward()
        self.assertTrue(torch.isfinite(loss))
        self.assertTrue(all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None))

    def test_forward_does_not_read_target_or_true_interval(self):
        model = self.model().eval()
        x = copy.deepcopy(self.sample)
        with torch.no_grad(): before = model('NYC', x)['logits']
        x['target'] = (x['target']+1)%len(self.assets['pois']); x['delta'] = 99999.
        with torch.no_grad(): after = model('NYC', x)['logits']
        torch.testing.assert_close(before, after, atol=0., rtol=0.)

    def test_source_gate_is_shared(self):
        model = self.model()
        self.assertIs(model.domains['NYC'].gate, model.domains['TKY'].gate)
        self.assertIsNot(model.domains['CA'].gate, model.source_gate)

    def test_ca_backbone_frozen(self):
        model = self.model(); model.freeze_for_ca()
        for name, p in model.named_parameters():
            if p.requires_grad: self.assertTrue(name.startswith('domains.CA.'), name)
        self.assertFalse(model.dictionary.requires_grad)
        self.assertFalse(next(model.interval.parameters()).requires_grad)
        self.assertTrue(next(model.domains['CA'].gate.parameters()).requires_grad)

    def test_ca_freeze_preserves_parameters_after_update(self):
        model = self.model(); model.freeze_for_ca(); model.eval()
        old = {n: p.detach().clone() for n,p in model.named_parameters() if not p.requires_grad}
        opt = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=.001)
        s = read(self.root/'prepared'/'CA'/'fold1'/'train.json')[0]
        loss = sample_loss(model, 'CA', s, model('CA', s), self.cfg['loss'])
        loss.backward(); opt.step()
        for n,p in model.named_parameters():
            if n in old: torch.testing.assert_close(p, old[n], rtol=0, atol=0)

    def test_query_context_affects_graph_attention(self):
        model = self.model().eval()
        x = copy.deepcopy(self.sample)
        with torch.no_grad(): a = model('NYC', x)['logits']
        x['hours'][-1] = (x['hours'][-1]+5)%24
        with torch.no_grad(): b = model('NYC', x)['logits']
        self.assertFalse(torch.equal(a,b))

    def test_exact_ranks_and_tie_break(self):
        np.testing.assert_array_equal(ranks([[1,1,0],[0,1,2]], [1,2]), [2,1])
        m = ranking_metrics([1,2,6,11])
        self.assertEqual(m['acc5'], .5)
        self.assertEqual(m['acc10'], .75)
        self.assertAlmostEqual(m['mrr'], (1+.5+1/6+1/11)/4)

    def test_brier_multiclass_definition(self):
        m = calibration(np.zeros((2,2)), [0,1])
        self.assertAlmostEqual(m['brier'], .5)
        self.assertAlmostEqual(m['nll'], np.log(2))
        self.assertAlmostEqual(m['ece_equal_mass'], .5)

    def test_temperature_rejects_test_fit_and_preserves_ranks(self):
        x = np.array([[3,1],[2,0],[0,2],[1,3.]])
        with self.assertRaises(ValueError): temperature_fit(x, [0,0,1,1], 'test')
        t = temperature_fit(x, [0,0,1,1], 'val')
        self.assertGreater(t, 0)
        np.testing.assert_array_equal(ranks(x,[0,0,1,1]), ranks(x/t,[0,0,1,1]))

    def test_holm_monotonic_and_bounded(self):
        self.assertEqual(holm([.01,.04,.02]), [.03,.04,.04])
        self.assertEqual(holm([.8,.9]), [1.,1.])

    def test_haversine_units(self):
        self.assertAlmostEqual(float(haversine([0,0],[0,1])), 111.19508, places=3)

    def test_geojson_holes(self):
        g = {'type':'Polygon','coordinates': [[[0,0],[3,0],[3,3],[0,3],[0,0]], [[1,1],[2,1],[2,2],[1,2],[1,1]]]}
        self.assertTrue(inside_geometry(.5,.5,g)); self.assertFalse(inside_geometry(1.5,1.5,g))

    def test_stress_does_not_mutate_assets(self):
        before = digest(self.assets)
        a = perturb_assets(self.assets, 'category_masking', 1., 2)
        self.assertFalse(any(a['categories']))
        self.assertEqual(before, digest(self.assets))

    def test_training_loader_has_no_test_dependency(self):
        path = self.root/'prepared'/'NYC'/'fold1'/'test.json'
        backup = path.read_bytes(); path.unlink()
        try:
            a, tr, va, pr = load_training(self.root/'prepared', 1, ['NYC'])
            self.assertTrue(tr['NYC'])
        finally: path.write_bytes(backup)

    def test_main_aggregation_rejects_synthetic(self):
        root = self.root/'fake'
        root.mkdir(exist_ok=True)
        (root/'metadata.json').write_text(json.dumps({'synthetic_data':True,'is_simulated_log':False}))
        with self.assertRaises(ValueError): aggregate([root], root/'summary.json')

    def test_primary_aggregation_rejects_stress(self):
        root = self.root/'fake_stress'; root.mkdir(exist_ok=True)
        (root/'metadata.json').write_text(json.dumps({'synthetic_data':False, 'is_simulated_log':False,
            'split':'test', 'valid_for_primary_reporting':False}))
        with self.assertRaises(ValueError): aggregate([root], root/'summary.json')

    def test_cluster_inference_recovers_known_effect(self):
        aa, bb = self.root/'paired_a', self.root/'paired_b'
        for root in [aa,bb]: root.mkdir(exist_ok=True)
        meta = {'synthetic_data':True, 'is_simulated_log':False, 'city':'NYC', 'fold':1,
                'seed':2026, 'split':'test', 'sample_sha256':'same', 'candidate_sha256':'same'}
        for root in [aa,bb]: (root/'metadata.json').write_text(json.dumps(meta))
        rows = [{'event':str(i),'user':str(i),'target':0,'rank':1} for i in range(10)]
        (aa/'predictions.json').write_text(json.dumps(rows))
        rows[0]['rank'] = 10
        (bb/'predictions.json').write_text(json.dumps(rows))
        r = paired_inference([aa],[bb], repeats=200,allow_synthetic=True)
        self.assertAlmostEqual(r['difference'],.1)
        self.assertTrue(0 < r['p_raw'] <= 1)

if __name__ == '__main__': unittest.main(verbosity=2)
