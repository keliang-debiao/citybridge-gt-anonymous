#!/usr/bin/env python3
"""Plot only values produced by this repository, never manuscript reference tables."""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

p = argparse.ArgumentParser()
p.add_argument('--summary', required=True); p.add_argument('--out', required=True)
a = p.parse_args()
d = json.loads(Path(a.summary).read_text())
fig, ax = plt.subplots(figsize=(12.8,7.2), dpi=300)
for city, item in d['datasets'].items():
    fold = sorted(item['folds'], key=int)
    ax.plot([int(f) for f in fold], [item['folds'][f]['acc5'] for f in fold], marker='o', label=city)
ax.set(xlabel='Temporal fold', ylabel='Acc@5', xticks=range(1,6))
ax.legend(); ax.spines[['top','right']].set_visible(False)
if d.get('synthetic_outputs'):
    ax.set_title('SYNTHETIC DATA — ACTUAL SMOKE EXECUTION — NOT PAPER RESULTS')
else:
    ax.set_title('Repository execution results')
fig.tight_layout(); Path(a.out).parent.mkdir(parents=True,exist_ok=True)
fig.savefig(a.out, dpi=300)
