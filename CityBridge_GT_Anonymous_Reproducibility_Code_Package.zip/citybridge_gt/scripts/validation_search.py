#!/usr/bin/env python3
"""One-pass coordinate search; reconstructed search design, not recovered search history."""
import argparse
import copy
import json
from pathlib import Path

import yaml

from citybridge.data import prepare
from citybridge.engine import train_run, evaluate
from citybridge.util import config, dump

p = argparse.ArgumentParser()
p.add_argument('--raw', required=True); p.add_argument('--out', required=True)
p.add_argument('--config', default='configs/paper.yaml')
p.add_argument('--fold', type=int, default=1); p.add_argument('--seed', type=int, default=2026)
a = p.parse_args()
root = Path(a.out)
if root.exists(): raise SystemExit('Use a fresh search directory')
root.mkdir(parents=True)
best = config(a.config)
families = [('model','prototypes',[16,32,64,128,256]),
            ('model','adapter_rank',[2,4,8,16,32]),
            ('model','periodic_topk',[2,4,8,16]),
            ('model','graph_layers',[1,2,3,4]),
            ('preprocessing','session_hours',[6,12,24,48])]
results = []
for section, key, values in families:
    family_results = []
    for value in values:
        cfg = copy.deepcopy(best); cfg[section][key] = value
        run = root/f'{key}_{value}'
        prepared = run/'prepared'
        for city in ['NYC','TKY']:
            prepare(Path(a.raw)/f'{city}.csv', prepared/city/f'fold{a.fold}', a.fold,
                    cfg['preprocessing'], city)
        train_run(prepared, run/'source', a.fold, a.seed, cfg)
        # Only validation is loaded. No call to test evaluation exists in this script.
        meta = evaluate(prepared, run/'source'/'best.pt', run/'validation', 'NYC', 'val')
        score = meta['metrics']['acc5']
        family_results.append((score, value, cfg))
        results.append({'family':key,'value':value,'validation_acc5':score})
    # Stable tie resolution follows order of prespecified values.
    winner = max(family_results, key=lambda r:r[0])
    best = winner[2]
dump(root/'validation_search.json', {'test_used':False, 'configurations':len(results), 'results':results,
     'design':'one-pass coordinate search; 22 candidates; not original search trace'})
(root/'selected_config.yaml').write_text(yaml.safe_dump(best, sort_keys=True))
