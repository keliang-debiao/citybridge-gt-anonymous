#!/usr/bin/env python3
"""Do not certify manuscript reproduction from synthetic evidence or formatted logs."""
import argparse
import json
from pathlib import Path

from citybridge.util import dump
p=argparse.ArgumentParser();p.add_argument('--evidence',required=True);p.add_argument('--out',required=True)
a=p.parse_args();e=Path(a.evidence);requirements={
 'data_provenance.json':'Raw source hashes, exact CA boundary, taxonomy/timezone policies',
 'frozen_split_manifest.json':'All 15 domain-fold prepared hashes and target IDs',
 'full_results.json':'All 75 real-data test prediction sets',
 'baseline_provenance.json':'Exact official baseline versions, licenses, deviations, uniform folds',
 'paired_inference_family.json':'Eight predefined paired comparisons and Holm correction',
 'perturbation_protocol.json':'Perturbation distributions and inference/retraining policy',
 'efficiency.json':'Actual device and 5 warm-up + 20 timed epochs',
 'parameter_freeze_audit.json':'CA trainable names and unchanged shared weights',
 'anonymity_review.json':'Human review of author traces, archive metadata and anonymous URL access',
 'paper_discrepancy_resolution.json':'Recorded resolutions of manuscript ambiguities and deviations',
}
missing=[{'file':f,'needed':v} for f,v in requirements.items() if not (e/f).is_file()]
invalid=[]
for f in requirements:
 if (e/f).is_file():
  r=json.loads((e/f).read_text())
  if r.get('synthetic_data') or r.get('synthetic_outputs') or r.get('is_simulated_log'):
   invalid.append(f)
# Presence alone never certifies scientific validity.
r={'direct_submission_reproduction_claim_ready':False,'missing':missing,'invalid_synthetic_evidence':invalid,
   'automated_validation':'presence and provenance checks only; reviewer must inspect evidence',
   'archive_can_be_submitted_as_reference_code_with_limitations':True}
dump(a.out,r)
print(json.dumps(r,indent=2))
raise SystemExit(2 if missing or invalid else 0)
