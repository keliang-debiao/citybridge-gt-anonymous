#!/usr/bin/env python3
"""Execute 5 source fits + 5 CA fits per seed. Never tunes on test performance."""
import argparse
from pathlib import Path

from citybridge.data import prepare
from citybridge.engine import train_run, evaluate, calibrate
from citybridge.statistics import aggregate
from citybridge.util import config, dump

p = argparse.ArgumentParser()
p.add_argument('--raw', required=True, help='canonical NYC.csv TKY.csv CA.csv')
p.add_argument('--out', required=True)
p.add_argument('--config', default='configs/paper.yaml')
p.add_argument('--synthetic', action='store_true')
p.add_argument('--prepare-only', action='store_true')
a = p.parse_args()
c = config(a.config)
root, raw = Path(a.out), Path(a.raw)
if root.exists(): raise SystemExit('Use a fresh output directory; no silent resume or overwrite')
prepared, outputs = root/'prepared', []
for fold in range(1,6):
    test_ids = {}
    for city in ['NYC','TKY','CA']:
        prepare(raw/f'{city}.csv', prepared/city/f'fold{fold}', fold, c['preprocessing'], city, a.synthetic)
# Cross-fold test disjointness is checked before any model fit.
import json
for city in ['NYC','TKY','CA']:
    seen = set()
    for fold in range(1,6):
        audit = json.loads((prepared/city/f'fold{fold}'/'audit.json').read_text())
        ids = set(audit['target_ids']['test'])
        if seen & ids: raise RuntimeError('Repeated test event across folds')
        seen |= ids
if a.prepare_only:
    print('Five-fold preparation and cross-fold target audit passed')
    raise SystemExit(0)
for fold in range(1,6):
    for seed in c['training']['seeds']:
        sr = root/'fits'/f'fold{fold}'/f'seed{seed}'/'source'
        ca = root/'fits'/f'fold{fold}'/f'seed{seed}'/'ca'
        train_run(prepared, sr, fold, seed, c)
        train_run(prepared, ca, fold, seed, c, 'ca', sr/'best.pt')
        for city, checkpoint in [('NYC',sr/'best.pt'),('TKY',sr/'best.pt'),('CA',ca/'best.pt')]:
            pred = root/'predictions'/city/f'fold{fold}'/f'seed{seed}'
            evaluate(prepared, checkpoint, pred/'val', city, 'val')
            evaluate(prepared, checkpoint, pred/'test', city, 'test')
            calibrate(pred/'val', pred/'test', pred/'calibration.json')
            outputs.append(str(pred/'test'))
aggregate(outputs, root/'results.json', a.synthetic)
dump(root/'suite.json', {'source_fits':25, 'ca_fits':25, 'test_prediction_sets':75,
                         'synthetic_data':a.synthetic, 'original_paper_results_verified':False})
