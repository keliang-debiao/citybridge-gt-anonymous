#!/usr/bin/env python3
"""Heuristic archive checks; an anonymous URL/access audit is still human-reviewed."""
import argparse
import json
import re
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--root',default='.');p.add_argument('--out',required=True)
a=p.parse_args();root=Path(a.root).resolve();findings=[]
patterns={
 'email':r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}',
 'personal_home_path':r'(?:/home/|/Users/|C:\\\\Users\\\\)[^\s/\\]+',
 'credential_like':r'(?:ghp_|sk-proj-|AKIA)[A-Za-z0-9_-]{16,}',
 'private_workspace_path':r'/workspace/scratch/[0-9a-f]{12}',
}
for path in sorted(root.rglob('*')):
 if not path.is_file() or any(x in path.parts for x in ['.git','__pycache__','.venv']):continue
 rel=str(path.relative_to(root))
 if path.suffix in ['.py','.md','.txt','.json','.yaml','.yml','.cff','.toml','.csv','.jsonl']:
  text=path.read_text(errors='replace')
  for kind,pattern in patterns.items():
   # The scanner's own literal definitions are not findings.
   if path.name=='anonymous_audit.py':continue
   searchable = re.sub(r'https?://[^\s<>]+', '', text) if kind=='personal_home_path' else text
   for m in re.finditer(pattern,searchable):findings.append({'path':rel,'kind':kind,'line':searchable[:m.start()].count('\n')+1})
 if path.name in ['.gitconfig','.env'] or path.suffix in ['.docx','.pdf']:
  findings.append({'path':rel,'kind':'metadata_review_needed'})
report={'heuristic_only':True,'findings':findings,'no_git_history_included':not (root/'.git').exists(),
        'author_identity_proved_absent':False,'reason':'No automated scan proves anonymity of every binary or third-party service'}
Path(a.out).parent.mkdir(parents=True,exist_ok=True)
Path(a.out).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'findings':len(findings),'git_directory_present':(root/'.git').exists()}))
