#!/usr/bin/env python3
import argparse
import csv
import json
from pathlib import Path

p=argparse.ArgumentParser(); p.add_argument('--summary',required=True);p.add_argument('--out',required=True)
a=p.parse_args();d=json.loads(Path(a.summary).read_text())
Path(a.out).parent.mkdir(parents=True,exist_ok=True)
with open(a.out,'w',newline='') as f:
    w=csv.writer(f);w.writerow(['dataset','metric','mean','sd_across_temporal_folds','synthetic_outputs'])
    for city,item in d['datasets'].items():
        for metric,v in item['summary'].items():w.writerow([city,metric,v['mean'],v['sd_across_folds'],d['synthetic_outputs']])
