#!/usr/bin/env python3
"""Validate the manuscript's 5 warm-up + 20 timed epoch requirement."""
import argparse
import json
from pathlib import Path

import numpy as np

from citybridge.util import dump
p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--out',required=True)
a=p.parse_args();root=Path(a.run);meta=json.loads((root/'run.json').read_text())
rows=[json.loads(s) for s in (root/'training.jsonl').read_text().splitlines()]
if len(rows)<25:raise SystemExit('Efficiency report requires at least 25 executed epochs; cannot invent missing timings')
timed=rows[5:25];t=np.array([r['training_seconds'] for r in timed])
mem=[r['peak_cuda_allocated_bytes'] for r in timed if r['peak_cuda_allocated_bytes'] is not None]
dump(a.out,{'warmup_epochs':5,'timed_epochs':20,'training_seconds_mean':float(t.mean()),
    'training_seconds_sd':float(t.std(ddof=1)), 'peak_cuda_allocated_bytes':max(mem) if mem else None,
    'device':meta['environment']['device'],'synthetic_data':meta['synthetic_data'],
    'parameters':meta['total_parameters'],'trainable_parameters':meta['trainable_parameters'],
    'timing_excludes_validation':True,'paper_speed_verified':False})
