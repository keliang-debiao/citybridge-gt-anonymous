# Data sources and canonical schema

## Public sources verified when preparing this package

- Foursquare NYC and Tokyo: https://sites.google.com/site/yangdingqi/home/foursquare-dataset — section “NYC and Tokyo Check-in Dataset”. The source describes 227,428 NYC and 573,703 Tokyo raw check-ins, with timestamps, GPS coordinates and fine categories. These raw counts differ from the processed counts in Table 2.
- Gowalla: https://snap.stanford.edu/data/loc-gowalla.html — native check-ins are `[user] [check-in time] [latitude] [longitude] [location id]`. Native SNAP has no semantic-category field or preselected California subset.
- Temperature scaling background: https://proceedings.mlr.press/v70/guo17a.html.
- Deterministic computation: https://docs.pytorch.org/docs/stable/generated/torch.use_deterministic_algorithms.html. Tests use the pinned local PyTorch version, not whatever version the stable URL later serves.

No raw data are redistributed. Download from the dataset owner and retain their terms and citations. There is no automatic network fetch during preprocessing or training.

## Canonical CSV

| Column | Required | Definition |
|---|---|---|
| `user_id` | Yes | Source pseudonymous visitor key |
| `poi_id` | Yes | Source location key, city-specific |
| `timestamp` | Yes | ISO 8601 timestamp with UTC offset, such as `2012-04-03T18:12:00+00:00` |
| `latitude` | Yes | Decimal degrees in [-90,90] |
| `longitude` | Yes | Decimal degrees in [-180,180] |
| `offset_minutes` | No | Local clock offset used for hour/weekday; defaults to timestamp offset |
| `category_id` | No | Fine category; empty means missing |
| `category_parent` | No | Published second-level parent ID; empty means unavailable |

Invalid timestamps without an offset are rejected instead of guessing a timezone. Exact duplicate canonical observations are merged. IDs may contain Unicode; prepared artifacts use hashes rather than raw IDs.

## Import Foursquare

```bash
python -m citybridge convert --input data/raw/dataset_TSMC2014_NYC.txt --output data/canonical/NYC.csv --format foursquare --taxonomy data/mappings/taxonomy.csv
python -m citybridge convert --input data/raw/dataset_TSMC2014_TKY.txt --output data/canonical/TKY.csv --format foursquare --taxonomy data/mappings/taxonomy.csv
```

The native importer expects eight tab-separated fields: user, venue, category ID, category name, latitude, longitude, timezone offset, UTC time. Taxonomy CSV columns are `category_id,category_parent`. If taxonomy is omitted, fine-category edges still work but parent-category edges are unavailable; this is not exact reproduction of a protocol requiring both.

## Import Gowalla California

```bash
python -m citybridge convert --input data/raw/loc-gowalla_totalCheckins.txt.gz --output data/canonical/CA.csv --format gowalla-ca --boundary data/mappings/california_exact.geojson
```

Supply the exact California benchmark Polygon/MultiPolygon, location list or equivalent versioned filtering definition. The supplied importer accepts GeoJSON and handles polygon holes. It does not silently replace the state with a rectangle. Boundary points follow the explicit ray-crossing convention in the code; original benchmark boundary behavior remains to be checked.

Native Gowalla conversion explicitly uses UTC (`offset_minutes=0`). To reproduce California local daily/weekly patterns, enrich offsets from a documented timezone database including DST **before** preparing folds. The original manuscript does not state the timezone convention. Do not infer it by selecting the convention that improves test scores.

Category-free CA is default. Mapped-category CA requires a provenance-backed POI/category map compatible with source categories. Joining the map must not use any outcome labels or test-derived statistics. Keep category-free and mapped-category runs in separate output directories.

## Prepared fold outputs

`assets.json` stores frozen POI vocabulary hashes, train-only features, graph edges, edge descriptors, transition counts, weekly profiles inside features, normalization and raw-event provenance hashes. `train.json`, `val.json` and `test.json` store encoded causal inputs plus target labels. `audit.json` stores eligible/retained targets, excluded users, unseen-POI target counts, coverage, source/config hashes and split target IDs.

The training loader reads train/validation data only. It never loads `test.json`. Asset construction happens once before training and is verified by hash at evaluation.

Input hashes alone do not prove that an arbitrary caller labeled data correctly. Compare all prepared artifacts with the approved source and protocol before interpreting results.
