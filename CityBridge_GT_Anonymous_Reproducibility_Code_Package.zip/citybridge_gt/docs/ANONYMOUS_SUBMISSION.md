# Anonymous review handoff

The ZIP contains a source repository layout, not an externally published repository. No remote project, account or sharing setting was created.

Before a blinded upload, inspect README, package metadata, citation metadata, notebook metadata if added, figures, logs and checkpoint contents for author/institution/account information. Keep citations to third-party datasets and methods intact. Remove Git history, remote URLs tied to authors, email addresses, user-home paths, tokens, personal file names and institutional acknowledgments. The heuristic scan in `scripts/anonymous_audit.py` supports this review but does not prove anonymity.

If a journal requests a URL, upload the reviewed tree to an appropriately anonymous repository, verify that editors/reviewers can access it without learning the author's identity, and use the real URL. No anonymous URL is fabricated in this package.

An appropriate description for the present archive is:

> Manuscript-derived reference code and synthetic execution examples are supplied for review. The code documents its implementation choices and the artifacts still required for verifying reproduction of the reported benchmark results.

Do not claim the included fictional logs are original training records. Replace or supplement the reference evidence with actual benchmark outputs before making a verified numerical-reproduction statement.

The source license covers newly written code. Third-party data and any subsequently integrated baseline code retain their own licenses. No upstream baseline source or real mobility record is redistributed here.
