# Reproducibility status

This archive is a runnable, anonymous, manuscript-derived reference implementation. It cannot honestly be described as the original code that produced the paper's tables. The supplied manuscript contains aggregate results but no original source tree, raw dataset package, exact split IDs, trained weights, per-seed predictions or original training logs.

## What is implemented

- Native Foursquare and Gowalla file importers, canonical CSV validation, deterministic duplicate handling and sessionization.
- Five visitor-relative expanding-window folds, frozen training k-core, causal prefixes, unknown-prefix token and closed-set coverage accounting.
- Training-only transition, geographical, weekly-profile and category graphs, unique event-pair provenance and explicit normalizers.
- Identity/prototype fusion, shared source gate and dictionary, contextual directed graph Transformer, causal trajectory Transformer, irregular periodic retrieval, predicted next-interval head and complete-candidate scoring.
- Source-city alternating optimization, mean/covariance bridge loss, CA adapter/full/scratch paths, parameter freezing and validation-only epoch selection.
- Full validation/test logits, exact ranks, Acc@1/5/10, full MRR, NDCG@10, validation-fitted temperature scaling, multiclass Brier/NLL and equal-mass ECE.
- Seed-first visitor-cluster bootstrap, visitor-level paired permutation and eight-comparison Holm correction.
- Ablation configuration generation and inference-channel perturbation commands, full-suite automation, validation-only coordinate search, basic result plot/CSV export and timing summary.
- Markov and popularity sanity baselines, deterministic synthetic inputs, clearly fictional log examples and actual execution evidence.

## What cannot be recovered from the manuscript alone

| Required evidence | Present in source material | Consequence |
|---|---|---|
| Original raw checksums and release versions | No | Public source identity can be documented, original bytes cannot be verified |
| Exact CA polygon/location list and boundary policy | No | CA row counts and POI vocabulary cannot be matched exactly |
| CA processed category mapping and mapping provenance | No | Primary category-free pipeline is runnable; mapped-category main result is not verified |
| Published fine-to-parent taxonomy version | No | Fine-category matching is available; parent matching needs the supplied versioned mapping |
| Timezone and DST convention for CA | No | Native importer uses UTC explicitly, not inferred California local time |
| Original fold manifests and per-visitor rounding | No | A deterministic rounding convention is documented here |
| Original implementation of missing-edge features, adapter placement and query context | No | Explicit choices are documented; numerical equivalence is not established |
| POI head/middle/tail cutoffs and session-stratum definition | Incomplete | Reference rules are documented and need confirmation |
| Distinction between duplicated-looking ablations | Incomplete | Two ablation pairs collapse under literal reading; no fabricated distinction is claimed |
| Official baseline commits, configurations and licenses | No | Named baseline reproduction remains external work |
| Perturbation distributions and whether models were retrained | No | Implemented stress protocol is a reference convention, not a verified Table 14 reproduction |
| Original weights, logits and seed-level logs | No | No evidence supports claiming the original numeric tables were reproduced |
| Exact 12.8M/4.1M architecture accounting and optimized timing implementation | No | Actual counts/times are emitted; they are not overwritten with paper values |

The attached text also refers to Supplementary Tables S2, S3 and S4, but these are absent from its document body. This archive does not invent their contents.

## Verified in the packaging environment

Read `evidence/verification.json`, `evidence/unit_tests.txt`, `evidence/actual_smoke/` and `evidence/verification_environment.json` for actual run records. Tests establish the properties asserted by the tests, not exact correspondence to all manuscript claims. No benchmark-scale experiments or RTX 4090 efficiency measurements were performed here. A second fresh toy run is compared for deterministic predictions.

## Evidence needed for a verified submission

1. Acquire exact source datasets and mapping/boundary files with permission; record checksums and versions.
2. Review the explicit implementation decisions and retain an approved protocol before viewing test scores.
3. Run and retain all 15 prepared domain-fold manifests, unique target IDs and closed-set coverage reports.
4. Run 25 source fits and 25 CA fits; retain all 75 test prediction sets plus validation logits and selected configs.
5. Integrate and verify official baseline implementations using the same folds, candidates, tuning budgets and metrics.
6. Compute ablations, transfer attribution, subgroups, calibration, robustness and inference from new saved outputs.
7. Measure model size and efficiency on the actual device and resolve departures from the manuscript.
8. Review the archive, account details, license, anonymous hosting URL and journal upload policy.

The supplied code can be submitted as a transparent reference implementation with these limits disclosed. It must not be submitted as verified original experimental evidence before these steps are complete.
