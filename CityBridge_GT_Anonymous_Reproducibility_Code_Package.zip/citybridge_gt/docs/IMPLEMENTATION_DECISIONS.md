# Explicit implementation decisions

These decisions resolve omissions or ambiguities in the supplied text. They are not claims about the unavailable original implementation.

| Topic | Reference implementation decision | Manuscript implication |
|---|---|---|
| Temporal splitting | For n targets of a visitor, boundaries are integer floors of n times 0.4/0.5/.../1.0 | Exact decile rounding was unspecified |
| Chronology across visitors | Uses visitor-relative target order as Table 1 says | A later-calendar event of one visitor can influence an earlier-calendar prediction of another; this is not a global real-time deployment split |
| Equal timestamps | Sort by timestamp then content hash; only strictly earlier events enter a prefix | Simultaneous events need an original-policy review |
| Iterative filtering | Deduplicate train-prefix/target event union, iteratively filter users/POIs by check-in count, freeze membership | Does not reassign partitions after filtering |
| Removed history events | Retain them as an unknown-prefix token; do not connect removed intermediate POIs into new transitions | Closed-set target coverage is separately reported |
| Transition evidence | Count each original observed event pair once, even if it occurs in many prefixes | Prevents inflated counts caused by prefix expansion |
| Graph directions | For directed i→j, node i attends its outgoing destination j | Direction of message aggregation was unspecified |
| Graph self edges | Add an explicit fifth self relation | Stabilizes nodes with no ordinary neighbors |
| Edge features | 34 transition values; learned per-relation missing vector; geographic relation exposes only log-distance; add log edge weight to contextual network input | Exact non-transition feature handling and use of edge weights were incomplete |
| Contextual network | Nonlinear edge+query interaction in ψ, squared-distance attention; 3 residual/norm/FFN blocks | A context-only additive scalar would cancel under softmax and is avoided |
| Query graph | Recompute the complete graph for the current observed prefix context; its node states encode all tokens and candidates in that query | No cached context-free approximation; substantially slower than claimed optimized timing |
| Coordinates | Train-only mean coordinates per POI, population coordinate SD; spherical kNN | Choice of mean versus fixed venue coordinate was unspecified |
| Weekly profiles | Train events, local supplied timezone offsets, L1 row normalization; top-10 cosine neighbors ≥0.30 | CA local offsets are absent from native SNAP and need enrichment for local-time matching |
| Categories | Source category IDs shared across cities; missing vector; parents only if supplied | Taxonomy version cannot be guessed; CA mapped categories must map to source category vocabulary |
| Prototype descriptor | 2 standardized coordinates +168 profile bins +log count +category embedding → MLP | Hidden descriptor architecture was unspecified |
| Gate | One shared source gate; copy into a CA-specific gate before adaptation | Matches source sharing and target update boundary |
| Time features | 32-D hour, weekday and Time2Vec features projected to hidden size; Time2Vec uses days relative to fixed 2000-01-01 epoch | Time units and embeddings were incomplete |
| Retrieval | Causal prior tokens only; signed cosine × nearest-lag kernel; stable top-k tie order | No current or target token is retrieved |
| Adapter | Rank-r residual adapter on fused sequence state; rank-r city context belongs to adapter parameters | Exact insertion point was unspecified |
| Time stabilization | Clamp log σ to [-5,3]; clamp μ to [-12,12] only for positive interval used in scores; clamp zero observed intervals to 1e-6 h for loss | Numerical stabilizers must be reviewed before exact matching |
| Missing category score | Zero explicit category prior for missing candidate categories; mask category loss | Prevents treating unknown category as a fabricated semantic class |
| CA update set | POI identity, preference output, category classifier, low-rank adapter/context, missing-category vector and gate | Shared category embedding, descriptor, dictionary, graph/sequence/time modules remain frozen |
| Frozen dropout | Shared backbone in eval mode during adapter adaptation | Avoids stochastic frozen feature changes |
| Bridge loss | 512 samples/city with replacement; unbiased covariance with 1e-4 ridge; unnormalized squared norms | Sampling without replacement was unspecified |
| Source checkpoint | Highest macro mean NYC/TKY validation Acc@5; earliest epoch wins ties | Manuscript says validation Acc@5 without joint-city aggregation rule |
| Source mini-batches | Alternate city batches; consume each city once per epoch, stop city when exhausted | No undocumented oversampling of smaller city |
| Batch memory | One query at a time, sum gradients over configured batch before one optimizer step | Optimizer batch=128; memory/time differs from fully batched production kernel |
| Activity groups | Count retained training sessions; bottom/top floor(15% of users), stable user-ID ties | Tie rule unspecified; for fewer than 7 users groups may be empty |
| POI strata | Frequency rank: top 20% POIs=head, next 30%=middle, remainder=tail | This cutoff is not stated in the paper and is provisional |
| Session strata | Observed prefix length plus one target, using original causal session prefix count | Future total session length is not used; Table 12's precise convention is unknown |
| Rank ties | Higher logit first, smaller fold candidate index first on ties | Same convention used by every included evaluator |
| Fold summary | Five seed means per fold, then unweighted fold mean and sample SD | Never treat 25 correlated runs as 25 independent folds |
| Cluster inference | Resample seeds then visitors, retaining a visitor's events across folds; compute equal-fold estimand. Permute one sign per visitor across seeds/folds | Extra resampling detail needed to reconstruct Table 15 exactly |
| Calibration | Full validation logits, scalar positive temperature, top-label equal-mass 10-bin ECE; full multiclass Brier without 1/C normalization | Table 13 does not specify whether NLL/Brier refer to pre- or post-temperature; this code reports both |
| Perturbations | Inference-time channel changes, fixed trained parameters and normalizers | Exact Table 14 protocol unspecified |
| Search | Optional 22-candidate one-pass coordinate search; no test loader | Not a recovery of the original 24-budget search history |

## Ablation ambiguities

“Without prototype space” and “identity space only” are the same forward model under the supplied equations unless a different graph or descriptor path is specified. “Without periodic-lag retrieval” and “local causal attention only” also coincide unless fusion or token paths differ. Both pairs remain explicit aliases in this code. Do not claim that this implementation independently explains the distinct numbers reported for those rows.

The gate's expected decline from head to tail is a hypothesis. No monotonicity constraint is imposed and no pretrained gate values are fabricated.

## Scalability

Geographic kNN uses a 3-D spherical cKDTree. Weekly cosine neighbors are computed in blocks. Transition counts use sparse sorted-key lookup. Semantic same-category edges are exact and can be dense. Full query-conditioned graph propagation is expensive and can require substantial time on CA. Changes such as semantic edge caps, graph caching, sampled softmax and approximate neighbor retrieval change the model and must be recorded before comparing results. Optimizing runtime should preserve the recorded numerical contract and be validated on a small exact case.
