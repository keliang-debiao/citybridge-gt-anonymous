# Manuscript to code map

| Manuscript component | Implementation | Notes |
|---|---|---|
| §3.2 task / §4.2 cleaning | `data.read_events`, `data.enumerate_instances` | Causal within-session prefixes |
| §3.3 Table 1 folds | `data.split_instances`, `scripts/run_suite.py` | Explicit visitor-relative floor boundaries |
| §3.5 transition graph | `data.build_assets` | 34-D transition descriptor, pair deduplication and provenance |
| §3.5 geo/period/category | `data.build_assets` | Training-only coordinates/profiles/taxonomy |
| §3.6 prototypes/evidence | `model.CityBridge.prototypes` | Shared dictionary and source gate, five evidence components |
| §3.7 graph Transformer | `model.GraphLayer` | Context interaction, directed distance attention |
| §3.8 causal/periodic states | `model.CityBridge.forward` | Transformer mask, seven periodic scales, top-8 retrieval |
| §3.9 next time and final score | `model.CityBridge.forward` | Predicted μ,σ; complete candidate score; no target interval in forward |
| §3.10 bridge/objective | `model.bridge_loss`, `model.sample_loss` | All five objective terms |
| §3.10 CA boundary | `model.CityBridge.freeze_for_ca`, `engine.train_run` | Source checkpoint gate copied; shared modules frozen |
| Algorithm 1 | `scripts/run_suite.py` | Preparation → source fit → CA adaptation → validation/test → calibration |
| Table 3 settings | `configs/paper.yaml` | LR=1e-3 and weight decay=1e-4 recovered from Word equation content |
| Tables 4–7 ranking | `metrics.py`, `statistics.aggregate` | Tables regenerate from saved run metrics, not reference constants |
| Table 8 transfer | `train --transfer scratch/full/adapter` | Category-free preparation default; mapped categories require provenance |
| Table 9 literature context | `assets/manuscript_reference_tables.json` | Transcribed context only, not experiments |
| Table 10 ablations | `experiments.ABLATIONS`, `ablation-config` | Two literal alias pairs remain unresolved |
| Table 11 leakage oracles | Documentation only | Invalid oracle numbers are not fabricated or silently mixed into official fits |
| Table 12 strata | Encoded row groups; saved per-event predictions | Provisional POI cutoffs documented |
| Table 13 calibration | `engine.calibrate`, `metrics.calibration` | All domains, validation logits only |
| Table 14 stress | `experiments.py`, `stress` command | Explicit inference-channel protocol, not certified original perturbation design |
| Table 15 inference | `statistics.paired_inference`, `statistics.holm` | Visitor clusters; 10,000 replicates by default |
| Table 16 sensitivity | `scripts/validation_search.py` | Reconstructed validation-only search |
| Table 17 audit | `prepare` → `audit.json` | Target IDs, coverage, train event provenance and graph hashes |
| Table 18 efficiency | `training.jsonl`, `scripts/efficiency_summary.py` | Actual device/counts; no paper values are inserted |
| Figures 1–4 / 13 concepts | Architecture equations and documentation | No claim to regenerate layout-only conceptual figures |
| Empirical figures | `scripts/plot_results.py`, saved calibration JSON/logs | Basic fold plot provided; full original figures require original traces |

All nineteen source tables are preserved as **manuscript reference transcriptions** for manual comparison. They are excluded from the computation path. Running the code is not expected to reproduce those values without data/protocol alignment.
