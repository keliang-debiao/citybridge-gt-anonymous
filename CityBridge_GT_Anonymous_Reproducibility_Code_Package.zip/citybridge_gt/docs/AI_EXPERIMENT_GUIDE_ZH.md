# CityBridge-GT AI 实验执行指南

本包用于指导 AI 执行论文对应的实验流程。它是依据论文重新编写的参考实现，已在人工生成的小数据上实际跑通；不是原作者实验目录的恢复，也没有完成真实 NYC、TKY、CA 上的论文数值复现。首先阅读本文件，再按阶段执行。不得把模拟日志、论文表格常数或小数据自测结果写成真实实验结果。

## 一 文件先看哪里

| 文件 | 用途 |
|---|---|
| `README.md` | 英文匿名仓库首页与快速运行命令 |
| `configs/paper.yaml` | 论文表 3 的模型、优化和五种子配置 |
| `docs/IMPLEMENTATION_DECISIONS.md` | 原文未明确细节、实现选择与需要确认的差异 |
| `docs/PAPER_CODE_MAP.md` | 正文模块和代码位置对应表 |
| `docs/DATA.md` | 数据格式、公开来源、CA 地区和类别映射要求 |
| `docs/BASELINES.md` | 官方基线接入标准及尚未接入的基线 |
| `examples/simulated_logs/` | 75 份虚构日志，仅演示 3 域×5 折×5 种子的记录格式 |
| `evidence/actual_smoke/` | 在人工生成数据上真实执行的权重、训练日志、预测和校准结果 |
| `evidence/verification.json` | 实际检查结果；与模拟日志分开 |
| `assets/manuscript_reference_tables.json` | 论文表格转录，只用于最终对照，训练和分析程序不读取 |

## 二 交给 AI 的总指令

可直接复制以下文字作为工作任务：

```text
你现在接管 CityBridge-GT 实验代码。先阅读 README.md、docs/DATA.md、
docs/IMPLEMENTATION_DECISIONS.md、docs/REPRODUCIBILITY_STATUS.md 和 configs/paper.yaml。

目标是依据预先确定的协议实际运行并保存可审计结果，不能通过修改指标、生成目标数值、
复制论文表格、伪造日志或使用测试集选参来“对齐论文”。

先运行单元测试和 smoke。把数据来源、SHA256、CA 筛选规则、类别映射、时区、
每访客切分取整、过滤顺序、邻接方向、长尾分组等协议整理出来。
缺失的原始材料列为缺项；如果只能采用新约定，明确记录为参考复现的实现选择。

正式训练之前生成全部 15 个域-折的数据审计，核查目标不重复、训练图证据来源、
闭集覆盖率、类别可用性和候选词表。当前按每访客相对时间切分，不等同于全局日历切分。
不得把同一 POI 边在训练和测试中自然重复出现误判为泄漏；检查的是边统计来源事件。

随后执行 5 折×5 种子源域学习和同折同种子 CA 迁移，保留验证集选择记录、
最佳权重、完整验证 logits、逐事件测试 rank、完整测试 logits 和环境信息。
训练时不要打开 test.json。CA 迁移必须验证共享骨干与时间头不更新。

基线必须使用经核实的官方代码或明确标注的重实现；不得把本包的 Markov 基线
改名为 CAGNN、BiGSL 或 City Matters。所有方法使用相同候选集、切分、最大长度和评测。

所有结果都从真实保存的预测计算。先在折内平均五个种子，再计算五折均值和样本标准差。
统计检验按访客聚类，保留同一访客跨折相关性，并执行预先定义的 8 项 Holm 校正。
温度只在验证 logits 上拟合。输出真实差异与限制，不以接近论文数值作为调参目标。

本包 examples/simulated_logs 的每一行都是虚构示例。
evidence/actual_smoke 仅证明小数据执行成功，不能作为论文实验依据。
完成时交付运行命令、依赖环境、配置、数据/权重/预测指纹、审计和差异报告。
```

## 三 安装和小规模核验

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install torch==2.5.1 --index-url https://download.pytorch.org/whl/cpu
python -m pip install -r requirements.txt
python -m pip install --no-deps -e .
python -m unittest discover -s tests -v
python -m citybridge smoke --out work/new_smoke
```

Windows PowerShell 将激活命令改为 `.venv\Scripts\Activate.ps1`。正式 GPU 实验安装与驱动兼容的 PyTorch 2.5.1 CUDA 版本，复制配置并设置 `training.device: cuda`。代码默认 CPU，是为了让审稿者先验证运行流程。

`smoke` 使用缩小的 16 维模型、1 个图层和 1 个序列层，Fold 1、种子 2026、训练 2 轮。其结果不能与 128 维正式配置或论文指标比较。

## 四 数据准备与必须确定的协议

从原始发布页获得 Foursquare NYC/TKY 和 Gowalla。按 `docs/DATA.md` 转换为标准 CSV。CA 的确切边界/地点列表、映射类别、时区政策和版本需要原始记录支持。没有映射材料时，使用默认无类别 CA 流程，不能宣称复现了论文有映射类别的 0.3274。

先执行全 15 份切分核验：

```bash
python scripts/run_suite.py --raw data/canonical --out work/preflight --prepare-only
```

逐份检查 `work/preflight/prepared/<city>/fold<k>/audit.json`：样本总数、保留数、用户过滤数、未见 POI 数、覆盖率、训练事件来源和候选数。与论文表 2、17 不一致时，记录差异并核对协议，不能通过删除不利样本追求结果一致。

代码会拒绝覆盖已有准备/训练/评测目录。若要重跑，请用新目录，保留原记录。

## 五 正式五折五种子运行

```bash
python scripts/run_suite.py --raw data/canonical --out runs/full --config configs/paper.yaml
```

共 25 次 NYC+TKY 联合源域训练，25 次 CA 迁移，75 份域-折-种子测试输出。每个训练目录包含 `run.json`、`training.jsonl`、`best.pt`、`selection.json`、`frozen_config.yaml`。每份验证/测试输出保存完整 logits、目标、逐事件 rank 与来源信息。

本代码为逐查询完整上下文建图的参考实现，正式大规模运行可能明显慢于论文表 18；不要把表内秒数写入新日志。先在小型真实训练子集估算时间和显存，确认协议后再运行完整计划。

## 六 单独训练与迁移

```bash
python -m citybridge train --work work/preflight/prepared --out runs/f1s2026_source --fold 1 --seed 2026 --stage source
python -m citybridge train --work work/preflight/prepared --out runs/f1s2026_ca --fold 1 --seed 2026 --stage ca --source runs/f1s2026_source/best.pt --transfer adapter
python -m citybridge evaluate --work work/preflight/prepared --checkpoint runs/f1s2026_ca/best.pt --out runs/ca_val --domain CA --split val
python -m citybridge evaluate --work work/preflight/prepared --checkpoint runs/f1s2026_ca/best.pt --out runs/ca_test --domain CA --split test
python -m citybridge calibrate --val runs/ca_val --test runs/ca_test --out runs/ca_calibration.json
```

迁移归因另建目录，分别设置 `--transfer full` 和 `--transfer scratch`。adapter/full 必须使用相同折、相同种子的源权重；scratch 不传 `--source`。切勿把 CA 适配描述为完全零样本外部验证。

## 七 消融、扰动和验证集搜索

生成一个消融配置后，重新训练，不在完整模型结果上直接减去论文给出的差值：

```bash
python -m citybridge ablation-config --name without_periodic --out work/no_periodic.yaml
python -m citybridge train --work work/preflight/prepared --out runs/no_periodic_f1s2026 --fold 1 --seed 2026 --config work/no_periodic.yaml
```

`without_category` 还需重新准备全部域，在 `prepare` 时使用 `--disable-categories`，使输入类别、语义边、类别损失和类别先验同时移除。仅把 λcat 置零不等于完整类别消融。

原文的两对消融在给定公式下重合：without prototype/identity only、without periodic/local only。本包保留其别名，不能用未说明的差异生成不同结果。

```bash
python -m citybridge stress --work work/preflight/prepared --checkpoint runs/f1s2026_source/best.pt --out runs/stress_edges10 --domain NYC --family transition_deletion --level 0.10
python -m citybridge stress --work work/preflight/prepared --checkpoint runs/f1s2026_source/best.pt --out runs/stress_cat50 --domain NYC --family category_masking --level 0.50
python -m citybridge stress --work work/preflight/prepared --checkpoint runs/f1s2026_source/best.pt --out runs/stress_coord500 --domain NYC --family coordinate_noise --level 500
python -m citybridge stress --work work/preflight/prepared --checkpoint runs/f1s2026_source/best.pt --out runs/stress_time30 --domain NYC --family timestamp_noise --level 30
```

坐标单位米、时间单位分钟，删除/遮蔽使用 0–1 比例。本包扰动为推理时通道压力测试：坐标高斯噪声、固定拓扑，时间噪声后保持观测顺序，不重新划分数据。论文原始扰动分布不详，不能宣称这些命令精确重现表 14。

可选的 22 配置验证集搜索：

```bash
python scripts/validation_search.py --raw data/canonical --out runs/validation_search
```

该脚本是重新约定的一轮坐标搜索，不是论文原始搜索记录。它只调用验证集评测，不调用测试评测。完成后使用 `selected_config.yaml` 运行独立完整套件，记录预算和选参规则。

## 八 汇总与统计

```bash
python scripts/export_tables.py --summary runs/full/results.json --out runs/full/main.csv
python scripts/plot_results.py --summary runs/full/results.json --out runs/full/folds.png
```

配对检验 JSON 格式为 `{"a":[模型25个测试目录],"b":[基线25个测试目录],"metric":"acc5"}`，两组顺序逐项对应。子组可增加 `"subgroup":["activity","inactive"]` 或 `["poi_group","tail"]`。

```bash
python -m citybridge inference --pairs private/nyc_acc5_pairs.json --out runs/stats/nyc_acc5.json --repeats 10000
```

预定义 8 项：NYC Acc@5/MRR、TKY Acc@5/MRR、CA Acc@5/MRR、NYC inactive Acc@5、NYC tail Acc@10。将 8 个结果文件逐个传给 `citybridge holm <8 files> --out runs/stats/family.json`。不得按显著性挑选比较家族。

真实主表默认拒绝 synthetic 输出；模拟日志没有合法主表元数据，不能作为输入。`--allow-synthetic` 仅用于小数据检查，输出会继续标注 synthetic。

## 九 效率和匿名审稿交付

真实计时至少完成 25 个 epoch，再执行：

```bash
python scripts/efficiency_summary.py --run runs/f1s2026_source --out runs/efficiency.json
python scripts/anonymous_audit.py --root . --out work/anonymity_scan.json
python scripts/submission_gate.py --evidence private/verified_evidence --out work/submission_status.json
```

效率脚本排除前 5 轮，统计随后 20 轮的训练时间；不足时直接报错，不生成补齐时间。本包串行推断时间没有执行论文的优化批推断协议，应明确区分。

匿名上传只提交源代码、说明、无身份元数据和合规实验产物；不提交 `.git`、本地账户、私人路径、令牌或未许可的原始位置记录。检查临时匿名仓库是否无需作者账户即可访问，并按期刊要求填入实际链接。本任务只生成代码 ZIP，不自动发布任何外部仓库。

当前提交门槛报告会显示未完成真实复现实验，这是对现有证据的准确描述。补齐真实数据、官方基线、逐样本结果与协议差异后，再决定论文和仓库可以作出哪些复现声明。
