# Baseline integration

The package includes explicit **popularity** and **first-order Markov** sanity baselines. They are not FPMC, CAGNN, BiGSL or City Matters and must not be labeled as such.

| Manuscript model | Baseline status in this package |
|---|---|
| Popularity / Markov sanity checks | Implemented in `baseline.py` |
| FPMC, ST-RNN, DeepMove, SASRec, PLSPL | Not reimplemented; integrate and verify the original method |
| STAN, GETNext, DCHL, ReHDM | Official source and fixed commit required |
| BiGSL, CAGNN, City Matters | Closest comparisons; verified official source and deviations required |
| GDPW, UPTRec, MSAHG | Official source and fixed commit required |

Bibliographic references are transcribed in `assets/manuscript_reference_tables.json`; no original repository URLs or commits are invented. The article's original baseline source/deviation table S4 was not supplied.

## Integration contract

Each baseline must accept the exact prepared domain-fold candidate vocabulary and event IDs. Its training process may read `assets.json`, `train.json` and `val.json`, select settings using validation Acc@5 with at most the prescribed 24 configurations, and write test predictions only after selecting a checkpoint. Training-only graphs must replace any baseline's all-data graph construction.

Write one result directory per dataset/fold/seed with:

- `predictions.json`: one object per test event, fields `event`, `user`, `target`, `rank`, `activity`, `poi_group`, `length_group`. Preserve the same event order or align by unique `event` IDs. Rank all candidates; no sampled negatives or repeat-POI masking.
- `metadata.json`: `city`, `fold`, `seed`, `split: "test"`, `synthetic_data`, `is_simulated_log: false`, `candidate_sha256`, `sample_sha256`, `metrics`, `valid_for_primary_reporting: true`. Candidate hash is `citybridge.util.digest` of the exact ordered `assets['pois']`; sample hash is SHA256 of the exact prepared test JSON bytes.
- `logits.npy`, `targets.npy` for full multiclass calibration. Validation outputs use the same schema with split `val` and identical checkpoint/candidate fingerprints.
- A provenance record containing upstream URL, commit, license, upstream config, local modifications, search plan, chosen checkpoint and local source hash. Never fill these from guesses.

Before paired inference, verify baseline metric calculations against `citybridge.metrics` using identical logits and candidate order. The paired inference command rejects unmatched events, candidate hashes, partitions and seed/fold identities.

Named baseline results in the paper are transcription targets only. No fake baseline outputs are included.
