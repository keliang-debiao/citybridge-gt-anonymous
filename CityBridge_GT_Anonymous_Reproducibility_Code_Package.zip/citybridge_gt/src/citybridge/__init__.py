"""CityBridge-GT manuscript-derived reference code; no empirical results implied."""
__version__ = "0.1.0"
