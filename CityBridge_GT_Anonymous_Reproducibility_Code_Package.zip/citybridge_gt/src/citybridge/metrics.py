import numpy as np
from scipy.special import logsumexp
from scipy.optimize import minimize_scalar


def ranks(logits, targets):
    x, y = np.asarray(logits), np.asarray(targets, dtype=int)
    chosen = x[np.arange(len(y)), y]
    # Index-ascending tie break. Same convention for all models.
    ix = np.arange(x.shape[1])[None, :]
    return 1+(x > chosen[:, None]).sum(1)+((x == chosen[:, None]) & (ix < y[:, None])).sum(1)


def per_event(rank):
    r = np.asarray(rank)
    return {'acc1': (r <= 1).astype(float), 'acc5': (r <= 5).astype(float),
            'acc10': (r <= 10).astype(float), 'mrr': 1./r,
            'ndcg10': (r <= 10)/np.log2(r+1)}


def ranking_metrics(rank):
    if not len(rank): raise ValueError('empty prediction set')
    return {k: float(v.mean()) for k, v in per_event(rank).items()}


def temperature_fit(logits, targets, split):
    if split != 'val': raise ValueError('temperature fitting requires validation logits')
    x, y = np.asarray(logits), np.asarray(targets, dtype=int)
    def nll(logt):
        total = 0.
        for lo in range(0, len(y), 128):
            z = np.asarray(x[lo:lo+128], dtype=float)/np.exp(logt)
            yy = y[lo:lo+128]
            total += float((logsumexp(z, axis=1)-z[np.arange(len(yy)), yy]).sum())
        return total/len(y)
    opt = minimize_scalar(nll, bounds=(-4, 4), method='bounded')
    return float(np.exp(opt.x))


def calibration(logits, targets, temperature=1., bins=10):
    x, y = np.asarray(logits), np.asarray(targets, dtype=int)
    conf, correct = np.empty(len(y)), np.empty(len(y))
    nll, brier = 0., 0.
    for lo in range(0, len(y), 128):
        z = np.asarray(x[lo:lo+128], dtype=float)/temperature
        yy = y[lo:lo+128]
        logp = z-logsumexp(z, axis=1, keepdims=True)
        prob = np.exp(logp)
        conf[lo:lo+len(yy)] = prob.max(1)
        correct[lo:lo+len(yy)] = prob.argmax(1) == yy
        nll -= float(logp[np.arange(len(yy)), yy].sum())
        brier += float(((prob*prob).sum(1)-2*prob[np.arange(len(yy)), yy]+1).sum())
    ece, curve = 0., []
    for ix in np.array_split(np.argsort(conf, kind='stable'), min(bins, len(y))):
        if not len(ix): continue
        a, c = float(correct[ix].mean()), float(conf[ix].mean())
        ece += len(ix)/len(y)*abs(a-c)
        curve.append({'count': len(ix), 'confidence': c, 'accuracy': a})
    return {'nll': nll/len(y), 'brier': brier/len(y),
            'ece_equal_mass': ece, 'reliability': curve}
