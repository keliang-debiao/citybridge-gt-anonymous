import hashlib
import json
import os
import platform
import random
import subprocess
from pathlib import Path

import numpy as np
import yaml


def dump(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, allow_nan=False) + '\n')


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def digest(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True).encode()).hexdigest()


def config(path):
    return yaml.safe_load(Path(path).read_text())


def seed_all(seed, deterministic=True):
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
    random.seed(seed)
    np.random.seed(seed)
    import torch
    torch.manual_seed(seed)
    torch.set_num_threads(1)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.use_deterministic_algorithms(deterministic)
    torch.backends.cudnn.benchmark = False


def environment():
    import torch
    return {'python': platform.python_version(), 'torch': torch.__version__,
            'numpy': np.__version__, 'cuda_runtime': torch.version.cuda,
            'cuda_available': torch.cuda.is_available(),
            'device': torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU',
            'deterministic': torch.are_deterministic_algorithms_enabled()}


def write_manifest(root):
    root = Path(root)
    files = {str(p.relative_to(root)): sha(p) for p in sorted(root.rglob('*'))
             if p.is_file() and p.name != 'SHA256SUMS.json' and '__pycache__' not in p.parts}
    dump(root / 'SHA256SUMS.json', files)
    return files
