import argparse
import copy
import json
from pathlib import Path

from .util import config, dump


def main():
    p = argparse.ArgumentParser(description='Anonymous manuscript-derived CityBridge-GT reference code')
    sub = p.add_subparsers(dest='command', required=True)
    q = sub.add_parser('convert')
    q.add_argument('--input', required=True); q.add_argument('--output', required=True)
    q.add_argument('--format', choices=['foursquare', 'gowalla-ca'], required=True)
    q.add_argument('--taxonomy'); q.add_argument('--boundary')
    q = sub.add_parser('prepare')
    q.add_argument('--input', required=True); q.add_argument('--out', required=True)
    q.add_argument('--domain', choices=['NYC', 'TKY', 'CA'], required=True)
    q.add_argument('--fold', type=int, required=True); q.add_argument('--config', default='configs/paper.yaml')
    q.add_argument('--synthetic', action='store_true'); q.add_argument('--disable-categories', action='store_true')
    q = sub.add_parser('train')
    q.add_argument('--work', required=True); q.add_argument('--out', required=True)
    q.add_argument('--fold', type=int, required=True); q.add_argument('--seed', type=int, required=True)
    q.add_argument('--config', default='configs/paper.yaml')
    q.add_argument('--stage', choices=['source', 'ca'], default='source'); q.add_argument('--source')
    q.add_argument('--transfer', choices=['adapter', 'full', 'scratch'], default='adapter')
    q = sub.add_parser('evaluate')
    q.add_argument('--work', required=True); q.add_argument('--checkpoint', required=True)
    q.add_argument('--out', required=True); q.add_argument('--domain', required=True)
    q.add_argument('--split', choices=['val', 'test'], default='test')
    q = sub.add_parser('calibrate')
    q.add_argument('--val', required=True); q.add_argument('--test', required=True); q.add_argument('--out', required=True)
    q = sub.add_parser('aggregate')
    q.add_argument('directories', nargs='+'); q.add_argument('--out', required=True)
    q.add_argument('--allow-synthetic', action='store_true')
    q = sub.add_parser('inference')
    q.add_argument('--pairs', required=True, help='JSON {a:[dirs],b:[dirs],metric,subgroup?}')
    q.add_argument('--out', required=True); q.add_argument('--repeats', type=int, default=10000)
    q.add_argument('--allow-synthetic', action='store_true')
    q = sub.add_parser('holm')
    q.add_argument('results', nargs=8); q.add_argument('--out', required=True)
    q = sub.add_parser('baseline')
    q.add_argument('--work', required=True); q.add_argument('--out', required=True); q.add_argument('--domain', required=True)
    q.add_argument('--fold', type=int, required=True); q.add_argument('--seed', type=int, default=2026)
    q.add_argument('--method', choices=['markov', 'popularity'], default='markov')
    q = sub.add_parser('toy'); q.add_argument('--out', required=True)
    q.add_argument('--users', type=int, default=8); q.add_argument('--events', type=int, default=80)
    q.add_argument('--pois', type=int, default=12); q.add_argument('--seed', type=int, default=17)
    q = sub.add_parser('smoke'); q.add_argument('--out', required=True); q.add_argument('--config', default='configs/paper.yaml')
    q = sub.add_parser('simulate-logs'); q.add_argument('--out', required=True)
    q = sub.add_parser('ablation-config'); q.add_argument('--name', required=True)
    q.add_argument('--config', default='configs/paper.yaml'); q.add_argument('--out', required=True)
    q = sub.add_parser('stress')
    q.add_argument('--work', required=True); q.add_argument('--checkpoint', required=True); q.add_argument('--out', required=True)
    q.add_argument('--domain', required=True)
    q.add_argument('--family', choices=['transition_deletion', 'category_masking', 'coordinate_noise', 'timestamp_noise'], required=True)
    q.add_argument('--level', type=float, required=True); q.add_argument('--perturb-seed', type=int, default=97)
    a = p.parse_args()
    if a.command == 'convert':
        from .convert import convert
        convert(a.input, a.output, a.format, a.taxonomy, a.boundary)
    elif a.command == 'prepare':
        from .data import prepare
        c = config(a.config)['preprocessing']
        c['disable_categories'] = a.disable_categories
        r = prepare(a.input, a.out, a.fold, c, a.domain, a.synthetic)
        print(json.dumps({k: r[k] for k in ['domain', 'fold', 'counts', 'synthetic']}, indent=2))
    elif a.command == 'train':
        from .engine import train_run
        train_run(a.work, a.out, a.fold, a.seed, config(a.config), a.stage, a.source, a.transfer)
    elif a.command == 'evaluate':
        from .engine import evaluate
        print(json.dumps(evaluate(a.work, a.checkpoint, a.out, a.domain, a.split), indent=2))
    elif a.command == 'calibrate':
        from .engine import calibrate
        calibrate(a.val, a.test, a.out)
    elif a.command == 'aggregate':
        from .statistics import aggregate
        aggregate(a.directories, a.out, a.allow_synthetic)
    elif a.command == 'inference':
        from .statistics import paired_inference
        r = json.loads(Path(a.pairs).read_text())
        dump(a.out, paired_inference(r['a'], r['b'], r.get('metric', 'acc5'), r.get('subgroup'),
                                    a.repeats, allow_synthetic=a.allow_synthetic))
    elif a.command == 'holm':
        from .statistics import holm
        rows = [json.loads(Path(p).read_text()) for p in a.results]
        if any(r.get('synthetic_outputs') for r in rows): raise ValueError('Holm paper family requires real runs')
        values = holm([r['p_raw'] for r in rows])
        dump(a.out, [dict(r, p_holm=v) for r, v in zip(rows, values)])
    elif a.command == 'baseline':
        from .baseline import run_baseline
        run_baseline(a.work, a.out, a.domain, a.fold, a.seed, a.method)
    elif a.command == 'toy':
        from .demo import make_toy
        make_toy(a.out, a.users, a.events, a.pois, a.seed)
    elif a.command == 'smoke':
        from .demo import smoke
        print(smoke(a.out, config(a.config)))
    elif a.command == 'simulate-logs':
        from .demo import simulated_logs
        simulated_logs(a.out)
    elif a.command == 'ablation-config':
        from .experiments import ablation_config
        import yaml
        Path(a.out).write_text(yaml.safe_dump(ablation_config(config(a.config), a.name)))
    elif a.command == 'stress':
        from .engine import evaluate
        evaluate(a.work, a.checkpoint, a.out, a.domain, 'test', (a.family, a.level, a.perturb_seed))


if __name__ == '__main__': main()
