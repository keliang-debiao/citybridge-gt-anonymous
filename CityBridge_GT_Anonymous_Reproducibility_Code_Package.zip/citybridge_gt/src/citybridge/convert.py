"""Explicit local-file importers. Downloads and redistribution are not automatic."""
import csv
import gzip
import json
from datetime import datetime
from pathlib import Path

from .util import dump, sha

FIELDS = ['user_id', 'poi_id', 'timestamp', 'latitude', 'longitude',
          'offset_minutes', 'category_id', 'category_parent']


def point_in_ring(x, y, ring):
    inside = False
    for a, b in zip(ring, ring[1:] + ring[:1]):
        ax, ay = a[:2]; bx, by = b[:2]
        if (ay > y) != (by > y) and x < (bx-ax)*(y-ay)/(by-ay)+ax:
            inside = not inside
    return inside


def inside_geometry(lon, lat, geo):
    if geo['type'] == 'Feature': return inside_geometry(lon, lat, geo['geometry'])
    if geo['type'] == 'FeatureCollection':
        return any(inside_geometry(lon, lat, f) for f in geo['features'])
    polygons = [geo['coordinates']] if geo['type'] == 'Polygon' else geo['coordinates'] if geo['type'] == 'MultiPolygon' else None
    if polygons is None: raise ValueError('CA boundary must be Polygon/MultiPolygon GeoJSON')
    return any(point_in_ring(lon, lat, poly[0]) and
               not any(point_in_ring(lon, lat, hole) for hole in poly[1:]) for poly in polygons)


def convert(source, output, kind, taxonomy=None, boundary=None):
    output = Path(output)
    if output.exists(): raise FileExistsError('Refusing to overwrite converted data')
    parents = {}
    if taxonomy:
        with open(taxonomy, newline='', encoding='utf-8-sig') as f:
            parents = {r['category_id']: r['category_parent'] for r in csv.DictReader(f)}
    geometry = json.loads(Path(boundary).read_text()) if boundary else None
    if kind == 'gowalla-ca' and geometry is None:
        raise ValueError('CA requires the exact benchmark GeoJSON boundary; no silent bounding-box approximation')
    count, rejected = 0, 0
    output.parent.mkdir(parents=True, exist_ok=True)
    opener = gzip.open if str(source).endswith('.gz') else open
    with opener(source, 'rt', encoding='utf-8-sig') as src, open(output, 'w', newline='') as dst:
        writer = csv.DictWriter(dst, fieldnames=FIELDS); writer.writeheader()
        for line in src:
            if not line.strip(): continue
            try:
                parts = line.rstrip('\n').split('\t')
                if kind == 'foursquare':
                    if len(parts) != 8: raise ValueError('Expected 8 tab-separated Foursquare fields')
                    u, p, cat, name, lat, lon, offset, timestamp = parts
                    t = datetime.strptime(timestamp, '%a %b %d %H:%M:%S %z %Y')
                    row = dict(zip(FIELDS, [u, p, t.isoformat(), lat, lon, offset, cat, parents.get(cat, '')]))
                elif kind == 'gowalla-ca':
                    if len(parts) != 5: parts = line.split()
                    if len(parts) != 5: raise ValueError('Expected 5 Gowalla fields')
                    u, timestamp, lat, lon, p = parts
                    if not inside_geometry(float(lon), float(lat), geometry): continue
                    # Native release has no timezone/category. Require an explicit
                    # local-time enrichment for paper-matched weekly profiles.
                    row = dict(zip(FIELDS, [u, p, timestamp, lat, lon, 0, '', '']))
                else: raise ValueError('Unknown format')
                writer.writerow(row); count += 1
            except (ValueError, IndexError): rejected += 1
    if not count: raise ValueError('No rows imported; check format and CA boundary')
    dump(str(output)+'.provenance.json', {'source_sha256': sha(source), 'rows': count, 'rejected': rejected,
        'format': kind, 'boundary_sha256': sha(boundary) if boundary else None,
        'taxonomy_sha256': sha(taxonomy) if taxonomy else None,
        'timezone_policy': 'source_offset' if kind == 'foursquare' else 'UTC_no_inferred_timezone',
        'category_mapping': 'fine_and_supplied_parent' if taxonomy else 'fine_only_or_missing'})
