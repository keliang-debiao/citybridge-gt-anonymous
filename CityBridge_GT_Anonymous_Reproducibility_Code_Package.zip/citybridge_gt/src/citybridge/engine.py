import json
import math
import time
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

from .model import CityBridge, sample_loss, bridge_loss
from .metrics import ranks, ranking_metrics, temperature_fit, calibration
from .util import dump, sha, digest, seed_all, environment


def read(path): return json.loads(Path(path).read_text())


def load_training(work, fold, cities):
    # Deliberately has NO test loader. Training cannot select on test predictions.
    assets, train, val, provenance = {}, {}, {}, {}
    for city in cities:
        root = Path(work)/city/f'fold{fold}'
        assets[city] = read(root/'assets.json')
        train[city], val[city] = read(root/'train.json'), read(root/'val.json')
        provenance[city] = {k: sha(root/k) for k in ['assets.json', 'train.json', 'val.json', 'audit.json']}
    return assets, train, val, provenance


def predict(model, city, samples):
    model.eval()
    out = []
    with torch.no_grad():
        for s in samples:
            out.append(model(city, s)['logits'].cpu().numpy())
    return np.stack(out)


def train_run(work, out, fold, seed, cfg, stage='source', source=None, transfer='adapter'):
    out = Path(out)
    if out.exists() and any(out.iterdir()):
        raise FileExistsError(f'Run output exists: {out}')
    out.mkdir(parents=True, exist_ok=True)
    seed_all(seed, cfg['training']['deterministic'])
    device = torch.device(cfg['training']['device'])
    cities = ['NYC', 'TKY'] if stage == 'source' else ['CA']
    assets, train, val, provenance = load_training(work, fold, cities)
    frozen_source = None
    if stage == 'ca' and transfer != 'scratch':
        if source is None: raise ValueError('CA transfer requires selected source checkpoint')
        frozen_source = torch.load(source, map_location='cpu', weights_only=False)
        if frozen_source['fold'] != fold or frozen_source['seed'] != seed:
            raise ValueError('CA must use the same source fold and seed')
        if frozen_source['cfg']['model'] != cfg['model']:
            raise ValueError('CA model settings must match the source frozen configuration')
        if any(a['synthetic'] for a in frozen_source['assets'].values()) != any(a['synthetic'] for a in assets.values()):
            raise ValueError('Cannot mix synthetic and real source/target domains')
        source_assets = dict(frozen_source['assets'])
        source_assets.update(assets)
        model = CityBridge(source_assets, cfg['model'], frozen_source['cat_map'])
        state = model.state_dict()
        state.update(frozen_source['model'])
        model.load_state_dict(state)
        # Gate is shared during source learning, then copied and adapted on CA.
        model.domains['CA'].gate.load_state_dict(model.source_gate.state_dict())
        if transfer == 'adapter': model.freeze_for_ca()
    else:
        model = CityBridge(assets, cfg['model'])
    model.to(device)
    params = [p for p in model.parameters() if p.requires_grad]
    opt = torch.optim.AdamW(params, lr=cfg['training']['learning_rate'], weight_decay=cfg['training']['weight_decay'])
    synthetic = any(a['synthetic'] for a in assets.values())
    metadata = {'kind': 'ACTUAL_EXECUTION_ON_SYNTHETIC_DATA' if synthetic else 'REAL_DATA_EXECUTION',
                'is_simulated_log': False, 'synthetic_data': synthetic,
                'paper_result_reproduction_verified': False,
                'stage': stage, 'fold': fold, 'seed': seed, 'transfer': transfer,
                'configuration_sha256': digest(cfg), 'prepared_data': provenance,
                'source_checkpoint_sha256': sha(source) if frozen_source is not None else None,
                'trainable_parameters': sum(p.numel() for p in params),
                'total_parameters': sum(p.numel() for p in model.parameters()),
                'environment': environment(),
                'selection_metric': 'macro_city_validation_acc5' if stage == 'source' else 'CA_validation_acc5'}
    dump(out/'run.json', metadata)
    rng = np.random.default_rng(seed)
    best, patience, history = -math.inf, 0, []
    batch = cfg['training']['batch_size']
    logfile = out/'training.jsonl'
    for epoch in range(1, cfg['training']['epochs']+1):
        model.train()
        # Frozen source backbones stay in evaluation mode during adapter training.
        # Trainable domain modules remain in training mode (no dropout in those).
        if stage == 'ca' and transfer == 'adapter': model.eval()
        city_batches = {}
        for c in cities:
            ix = rng.permutation(len(train[c])).tolist()
            city_batches[c] = [ix[i:i+batch] for i in range(0, len(ix), batch)]
        steps = max(len(b) for b in city_batches.values())
        if device.type == 'cuda':
            torch.cuda.synchronize()
            torch.cuda.reset_peak_memory_stats()
        start = time.perf_counter()
        total_loss, updates = 0., 0
        for step in range(steps):
            # Alternate city batches, with one optimizer update per city batch.
            for city in cities:
                if step >= len(city_batches[city]): continue
                ii = city_batches[city][step]
                opt.zero_grad(set_to_none=True)
                loss_sum = 0.
                for i in ii:
                    s = train[city][i]
                    result = model(city, s)
                    loss = sample_loss(model, city, s, result, cfg['loss'])/len(ii)
                    loss.backward()
                    loss_sum += float(loss.detach())
                if stage == 'source' and set(cities) == {'NYC', 'TKY'} and cfg['loss']['bridge']:
                    bridge = bridge_loss(model, cfg['loss']['bridge_batch'])*cfg['loss']['bridge']
                    bridge.backward()
                    loss_sum += float(bridge.detach())
                torch.nn.utils.clip_grad_norm_(params, cfg['training']['gradient_clip'])
                opt.step()
                total_loss += loss_sum
                updates += 1
        if device.type == 'cuda': torch.cuda.synchronize()
        elapsed = time.perf_counter()-start
        val_scores = {}
        for city in cities:
            model.eval()
            hits = 0
            with torch.no_grad():
                for sample in val[city]:
                    logits = model(city, sample)['logits'].cpu().numpy()
                    hits += int(ranks(logits[None, :], [sample['target']])[0] <= 5)
            val_scores[city] = hits/len(val[city])
        score = float(np.mean(list(val_scores.values())))
        selected = score > best
        if selected:
            best, patience = score, 0
            checkpoint = {'model': model.state_dict(), 'cfg': cfg,
                          'assets': {c: a for c, a in model_assets(model, assets, frozen_source).items()},
                          'cat_map': model.cat_map, 'fold': fold, 'seed': seed,
                          'epoch': epoch, 'validation_acc5': val_scores, 'metadata': metadata}
            torch.save(checkpoint, out/'best.pt')
            # Exact executed settings, not a claim that an unavailable original config was recovered.
            import yaml
            (out/'frozen_config.yaml').write_text(yaml.safe_dump(cfg, sort_keys=True))
        else:
            patience += 1
        row = {'epoch': epoch, 'training_loss': total_loss/max(updates, 1),
               'validation_acc5': val_scores, 'selected': selected,
               'training_seconds': elapsed,
               'peak_cuda_allocated_bytes': torch.cuda.max_memory_allocated() if device.type == 'cuda' else None,
               'synthetic_data': synthetic,
               'is_simulated_log': False, 'fold': fold, 'seed': seed, 'stage': stage}
        history.append(row)
        with open(logfile, 'a') as f: f.write(json.dumps(row, allow_nan=False)+'\n')
        if patience >= cfg['training']['patience']: break
    dump(out/'selection.json', {'best_validation_acc5': best, 'epochs_executed': len(history),
                               'checkpoint_sha256': sha(out/'best.pt')})
    return metadata


def model_assets(model, new_assets, source):
    assets = {} if source is None else dict(source['assets'])
    assets.update(new_assets)
    return assets


def evaluate(work, checkpoint, out, city, split='test', perturbation=None):
    out = Path(out)
    if out.exists(): raise FileExistsError('Evaluation output already exists; test evaluation is write-once')
    ckpt = torch.load(checkpoint, map_location='cpu', weights_only=False)
    seed_all(ckpt['seed'], ckpt['cfg']['training']['deterministic'])
    model = CityBridge(ckpt['assets'], ckpt['cfg']['model'], ckpt['cat_map'])
    model.load_state_dict(ckpt['model'])
    device = ckpt['cfg']['training']['device']
    model.to(device)
    root = Path(work)/city/f"fold{ckpt['fold']}"
    if sha(root/'assets.json') != ckpt['metadata']['prepared_data'][city]['assets.json']:
        # CA checkpoint metadata includes CA only; source checkpoint source cities only.
        raise ValueError('Prepared assets changed after fitting')
    samples = read(root/f'{split}.json')
    if perturbation is not None:
        from .experiments import perturb_assets, perturb_sample
        family, level, perturb_seed = perturbation
        if family != 'timestamp_noise':
            changed = dict(ckpt['assets'])
            changed[city] = perturb_assets(changed[city], family, level, perturb_seed)
            stressed = CityBridge(changed, ckpt['cfg']['model'], ckpt['cat_map']).to(device)
            params = dict(model.named_parameters())
            with torch.no_grad():
                for name, param in stressed.named_parameters(): param.copy_(params[name])
            model = stressed
        if family in ('coordinate_noise', 'timestamp_noise'):
            samples = [perturb_sample(s, family, level, perturb_seed+i) for i, s in enumerate(samples)]
    out.mkdir(parents=True)
    n, c = len(samples), len(ckpt['assets'][city]['pois'])
    # Full logits in disk-backed .npy, never just top-k: required for multiclass calibration.
    logits = np.lib.format.open_memmap(out/'logits.npy', mode='w+', dtype='float32', shape=(n, c))
    model.eval()
    elapsed, peak = 0., 0
    with torch.no_grad():
        for i, s in enumerate(samples):
            if str(device).startswith('cuda'): torch.cuda.synchronize()
            tick = time.perf_counter()
            pred = model(city, s)
            if str(device).startswith('cuda'): torch.cuda.synchronize()
            elapsed += time.perf_counter()-tick
            logits[i] = pred['logits'].cpu().numpy()
    logits.flush()
    targets = np.array([s['target'] for s in samples], dtype='int64')
    rr = np.concatenate([ranks(logits[i:i+128], targets[i:i+128]) for i in range(0, n, 128)])
    rows = []
    for s, r in zip(samples, rr):
        rows.append({k: s[k] for k in ['event', 'user', 'activity', 'poi_group', 'length_group']} |
                    {'rank': int(r), 'target': s['target']})
    dump(out/'predictions.json', rows)
    np.save(out/'targets.npy', targets, allow_pickle=False)
    meta = {'city': city, 'fold': ckpt['fold'], 'seed': ckpt['seed'], 'split': split,
            'synthetic_data': ckpt['metadata']['synthetic_data'], 'is_simulated_log': False,
            'checkpoint_sha256': sha(checkpoint), 'config_sha256': digest(ckpt['cfg']),
            'sample_sha256': sha(root/f'{split}.json'), 'candidate_count': c,
            'candidate_sha256': digest(ckpt['assets'][city]['pois']),
            'inference_ms_per_query': 1000*elapsed/n, 'latency_protocol': 'serial_query_no_warmup_reference',
            'metrics': ranking_metrics(rr), 'perturbation': perturbation,
            'valid_for_primary_reporting': perturbation is None}
    dump(out/'metadata.json', meta)
    return meta


def calibrate(val_dir, test_dir, out):
    va, te = Path(val_dir), Path(test_dir)
    vm, tm = read(va/'metadata.json'), read(te/'metadata.json')
    if vm['split'] != 'val' or tm['split'] != 'test': raise ValueError('Expected val/test predictions')
    for k in ['city', 'fold', 'seed', 'checkpoint_sha256', 'candidate_sha256', 'synthetic_data']:
        if vm[k] != tm[k]: raise ValueError(f'Calibration provenance mismatch: {k}')
    vx, vy = np.load(va/'logits.npy', mmap_mode='r'), np.load(va/'targets.npy')
    tx, ty = np.load(te/'logits.npy', mmap_mode='r'), np.load(te/'targets.npy')
    t = temperature_fit(vx, vy, 'val')
    result = {'temperature': t, 'fitted_on': 'validation_logits_only',
              'synthetic_data': vm['synthetic_data'], 'is_simulated_log': False,
              'city': vm['city'], 'fold': vm['fold'], 'seed': vm['seed'],
              'validation_logits_sha256': sha(va/'logits.npy'),
              'test_logits_sha256': sha(te/'logits.npy'),
              'before': calibration(tx, ty), 'after': calibration(tx, ty, t)}
    dump(out, result)
    return result
