"""Differentiable implementation of Sections 3.5--3.10, with explicit query contexts."""
import math

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from .data import haversine


def mlp(a, b, c):
    return nn.Sequential(nn.Linear(a, b), nn.GELU(), nn.Linear(b, c))


class Time2Vec(nn.Module):
    def __init__(self, size):
        super().__init__()
        self.linear = nn.Linear(1, 1)
        self.periodic = nn.Linear(1, size-1)

    def forward(self, t):
        return torch.cat([self.linear(t), torch.sin(self.periodic(t))], -1)


class GraphLayer(nn.Module):
    def __init__(self, h, heads, ff, ctx, dropout, attention='distance'):
        super().__init__()
        self.heads, self.width, self.attention = heads, h//heads, attention
        self.q, self.k, self.v = [nn.Linear(h, h, bias=False) for _ in range(3)]
        self.rb = nn.Embedding(5, heads)
        self.rv = nn.Embedding(5, h)
        self.missing = nn.Parameter(torch.zeros(5, 34))
        # Bilinear edge-context interactions are essential: additive context alone
        # cancels in the neighborhood softmax and would NOT be context adaptive.
        self.edge = nn.Linear(35, h)
        self.context = nn.Linear(ctx, h)
        self.psi = nn.Linear(h, heads)
        self.gat = nn.Parameter(torch.zeros(heads, self.width*2))
        nn.init.xavier_uniform_(self.gat)
        self.out = nn.Linear(h, h)
        self.norm1, self.norm2 = nn.LayerNorm(h), nn.LayerNorm(h)
        self.ff = nn.Sequential(nn.Linear(h, ff), nn.GELU(), nn.Dropout(dropout), nn.Linear(ff, h))
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, context, graph):
        src, dst, rel, weight, phi, mask = graph
        n, h = x.shape
        q, k, v = [layer(x).view(n, self.heads, self.width) for layer in (self.q, self.k, self.v)]
        if self.attention == 'gat':
            score = F.leaky_relu((torch.cat([q[src], k[dst]], -1)*self.gat).sum(-1), .2)
        else:
            score = -(q[src]-k[dst]).square().sum(-1)/math.sqrt(self.width)
        score = score + self.rb(rel)
        if self.attention == 'distance':
            inp = mask*phi + (1-mask)*self.missing[rel]
            inp = torch.cat([inp, torch.log(weight.clamp_min(1e-12))[:, None]], -1)
            score = score + self.psi(torch.tanh(self.edge(inp)+self.context(context)))
        # distance_no_context omits psi; gat replaces distance attention.
        index = src[:, None].expand(-1, self.heads)
        maximum = torch.full((n, self.heads), -torch.inf, device=x.device, dtype=x.dtype)
        maximum = maximum.scatter_reduce(0, index, score, reduce='amax', include_self=True)
        exp = (score-maximum[src]).exp()
        denom = torch.zeros_like(maximum).scatter_add(0, index, exp)
        alpha = exp/denom[src].clamp_min(1e-12)
        msg = alpha[:, :, None]*(v[dst]+self.rv(rel).view(-1, self.heads, self.width))
        agg = torch.zeros((n, self.heads, self.width), device=x.device, dtype=x.dtype)
        agg = agg.scatter_add(0, src[:, None, None].expand_as(msg), msg).reshape(n, h)
        x = self.norm1(x+self.dropout(self.out(agg)))
        return self.norm2(x+self.dropout(self.ff(x)))


class Domain(nn.Module):
    def __init__(self, assets, cfg, cat_map):
        super().__init__()
        h, r = cfg['hidden'], cfg['adapter_rank']
        self.n = len(assets['pois'])
        self.category_free = assets['category_free']
        self.identity = nn.Embedding(self.n, h)
        nn.init.normal_(self.identity.weight, std=.02)
        self.output = nn.Linear(h, h, bias=False)
        self.cat_head = nn.Linear(h, len(cat_map))
        self.adapter_a, self.adapter_b = nn.Linear(h, r, bias=False), nn.Linear(r, h, bias=False)
        nn.init.zeros_(self.adapter_b.weight)
        self.city_context = nn.Parameter(torch.zeros(r))
        self.missing_category = nn.Parameter(torch.zeros(cfg['category_dim']))
        self.gate = mlp(5, 32, 1)
        self.register_buffer('features', torch.tensor(assets['features'], dtype=torch.float32))
        self.register_buffer('evidence', torch.tensor(assets['evidence'], dtype=torch.float32))
        cats = [cat_map.get(c, 0) if c else 0 for c in assets['categories']]
        self.register_buffer('categories', torch.tensor(cats, dtype=torch.long))
        self.register_buffer('coords', torch.tensor(assets['coords'], dtype=torch.float32))
        edges = assets['edges']
        self.register_buffer('src', torch.tensor([e[0] for e in edges], dtype=torch.long))
        self.register_buffer('dst', torch.tensor([e[1] for e in edges], dtype=torch.long))
        self.register_buffer('rel', torch.tensor([e[2] for e in edges], dtype=torch.long))
        self.register_buffer('weight', torch.tensor([e[3] for e in edges], dtype=torch.float32))
        self.register_buffer('phi', torch.tensor([e[4] for e in edges], dtype=torch.float32))
        self.register_buffer('mask', torch.tensor([e[5] for e in edges], dtype=torch.float32))
        # Sparse count lookup avoids N^2 storage for the large CA vocabulary.
        keys, values = zip(*sorted((i*self.n+j, count) for i, j, count in assets['transitions'])) if assets['transitions'] else ([], [])
        self.register_buffer('transition_keys', torch.tensor(keys, dtype=torch.long))
        self.register_buffer('transition_values', torch.tensor(values, dtype=torch.float32))

    def transition_row(self, current):
        if current >= self.n or not len(self.transition_keys):
            return torch.zeros(self.n, device=self.features.device)
        a = torch.searchsorted(self.transition_keys, current*self.n)
        b = torch.searchsorted(self.transition_keys, (current+1)*self.n)
        out = torch.zeros(self.n, device=self.features.device)
        return out.scatter(0, self.transition_keys[a:b]-current*self.n, self.transition_values[a:b])

    def graph(self):
        return self.src, self.dst, self.rel, self.weight, self.phi, self.mask


class CityBridge(nn.Module):
    def __init__(self, assets_by_city, cfg, cat_map=None):
        super().__init__()
        self.cfg = dict(cfg)
        h, td, cd = cfg['hidden'], cfg['time_dim'], cfg['category_dim']
        if h % cfg['heads']:
            raise ValueError('hidden must be divisible by heads')
        if cat_map is None:
            categories = sorted({c for a in assets_by_city.values() for c in a['categories'] if c})
            cat_map = {'__MISSING__': 0, **{c: i+1 for i, c in enumerate(categories)}}
        self.cat_map = cat_map
        self.category = nn.Embedding(len(cat_map), cd)
        self.hour, self.weekday = nn.Embedding(24, td), nn.Embedding(7, td)
        self.hour_proj, self.weekday_proj = nn.Linear(td, h), nn.Linear(td, h)
        self.cat_proj = nn.Linear(cd, h)
        self.time2vec, self.time_proj = Time2Vec(td), nn.Linear(td, h)
        self.position = nn.Embedding(cfg['max_length'], h)
        self.descriptor = mlp(171+cd, h, h)
        self.dictionary = nn.Parameter(torch.randn(cfg['prototypes'], h)*.05)
        ctx = 2*td+1+cfg['adapter_rank']
        self.graph_layers = nn.ModuleList([GraphLayer(h, cfg['heads'], cfg['feedforward'], ctx,
                  cfg['dropout'], cfg['graph_attention']) for _ in range(cfg['graph_layers'])])
        layer = nn.TransformerEncoderLayer(h, cfg['heads'], cfg['feedforward'], cfg['dropout'],
                                          activation='gelu', batch_first=True, norm_first=False)
        self.trajectory = nn.TransformerEncoder(layer, cfg['trajectory_layers'], enable_nested_tensor=False)
        self.period_query, self.period_value = nn.Linear(h, h), nn.Linear(h, h)
        self.period_gate = nn.Linear(2*h+1, 1)
        self.interval = mlp(h, h, 2)
        self.unknown = nn.Parameter(torch.zeros(1, h))
        self.source_gate = mlp(5, 32, 1)
        self.domains = nn.ModuleDict({k: Domain(a, cfg, cat_map) for k, a in assets_by_city.items()})
        for city in ('NYC', 'TKY'):
            if city in self.domains: self.domains[city].gate = self.source_gate

    def category_vectors(self, d):
        v = self.category(d.categories)
        return torch.where((d.categories > 0)[:, None], v, d.missing_category[None, :])

    def prototypes(self, city):
        d = self.domains[city]
        z = self.descriptor(torch.cat([d.features, self.category_vectors(d)], -1))
        dist = (z[:, None, :]-self.dictionary[None, :, :]).square().sum(-1)
        pi = F.softmax(-dist/self.cfg['prototype_temperature'], -1)
        proto = pi @ self.dictionary
        entropy = -(pi*pi.clamp_min(1e-12).log()).sum(-1, keepdim=True)
        evidence = torch.cat([d.evidence[:, :3], entropy, d.evidence[:, 3:]], -1)
        gate = torch.sigmoid(d.gate(evidence))
        mode = self.cfg['representation']
        if mode in ('identity', 'no_prototypes'):
            state = d.identity.weight
        elif mode == 'prototype':
            state = proto
        elif mode == 'fixed_gate':
            state = .5*d.identity.weight+.5*proto
        else:
            state = gate*d.identity.weight+(1-gate)*proto
        return state, proto, gate

    def forward(self, city, sample):
        d, device = self.domains[city], self.dictionary.device
        to = lambda x, dt=torch.long: torch.as_tensor(x, dtype=dt, device=device)
        ids, hours, weekdays = to(sample['pois']), to(sample['hours']), to(sample['weekdays'])
        elapsed = to(sample['elapsed'], torch.float32)
        times = to(sample['times'], torch.float64)
        context = torch.cat([self.hour(hours[-1]), self.weekday(weekdays[-1]),
                             elapsed[-1:].log1p(), d.city_context])
        graph, proto, gate = self.prototypes(city)
        for layer in self.graph_layers:
            graph = layer(graph, context, d.graph())
        # Conditioning is on the final observed query only; no target timestamp enters.
        # For each prefix query, a fresh graph is computed. This is slow but exact
        # for the documented context convention (see docs/IMPLEMENTATION_DECISIONS.md).
        all_graph = torch.cat([graph, self.unknown], 0)
        all_cat = torch.cat([self.category_vectors(d), d.missing_category[None, :]], 0)
        tokens = all_graph[ids] + self.hour_proj(self.hour(hours)) + self.weekday_proj(self.weekday(weekdays))
        tokens = tokens + self.cat_proj(all_cat[ids]) + self.position(torch.arange(len(ids), device=device))
        # Fixed epoch 2000, hours rescaled to days; not fitted to validation/test.
        tt = (times.to(torch.float64)-262968.)/24.
        tokens = tokens + self.time_proj(self.time2vec(tt.to(torch.float32)[:, None]))
        length = len(ids)
        causal = torch.triu(torch.ones(length, length, dtype=torch.bool, device=device), diagonal=1)
        local = self.trajectory(tokens[None, :, :], mask=causal)[0, -1]
        periodic = torch.zeros_like(local)
        if self.cfg['periodic'] and length > 1:
            v = self.period_query(tokens)
            cos = F.cosine_similarity(v[-1:], v[:-1], dim=-1)
            lags = to([1, 3, 6, 12, 24, 48, 168], torch.float32)
            sigma = torch.maximum(torch.ones_like(lags), .15*lags)
            delta = (times[-1]-times[:-1]).to(torch.float32)
            rho = cos*torch.exp(-(delta[:, None]-lags).abs()/sigma).max(-1).values
            k = min(self.cfg['periodic_topk'], length-1)
            # Stable tie convention preserves chronological order.
            top = torch.argsort(rho, descending=True, stable=True)[:k]
            periodic = (F.softmax(rho[top], 0)[:, None]*self.period_value(tokens[:-1][top])).sum(0)
            beta = torch.sigmoid(self.period_gate(torch.cat([local, periodic, elapsed[-1:].log1p()])))
            state = beta*local+(1-beta)*periodic
        else:
            state = local
        if self.cfg['adapter']:
            state = state+d.adapter_b(F.gelu(d.adapter_a(state)))
        mu, logsigma = self.interval(state).unbind(-1)
        logsigma = logsigma.clamp(-5., 3.)
        # Overflow protection is an implementation choice, not a fitted statistic.
        predicted = mu.clamp(-12., 12.).exp() if self.cfg['time_head'] else torch.ones_like(mu)
        pref = graph @ d.output(state)
        category_logits = d.cat_head(state)
        if d.category_free:
            cat_score = torch.zeros_like(pref)
        else:
            cat_score = F.log_softmax(category_logits, -1)[d.categories]
            cat_score = torch.where(d.categories > 0, cat_score, torch.zeros_like(cat_score))
        transition = torch.log1p(d.transition_row(int(ids[-1])))
        # Coordinates in sample are ONLY last observed coordinates.
        current = to(sample['current_coord'], torch.float32)
        a, b = torch.deg2rad(current), torch.deg2rad(d.coords)
        dv = b-a
        hv = (dv[:, 0]/2).sin().square()+a[0].cos()*b[:, 0].cos()*(dv[:, 1]/2).sin().square()
        dist = 6371.0088*2*torch.asin(hv.clamp(0, 1).sqrt())
        geo = dist/(1e-6+self.cfg['vmax']*predicted)
        logits = pref+self.cfg['lambda_transition']*transition+self.cfg['lambda_category']*cat_score
        if self.cfg['reachability']:
            logits = logits-self.cfg['lambda_geo']*geo
        graph_logits = graph @ d.output(all_graph[ids[-1]])
        return {'logits': logits, 'sequence_logits': pref, 'graph_logits': graph_logits,
                'category_logits': category_logits, 'mu': mu, 'logsigma': logsigma,
                'predicted_delta': predicted, 'gate': gate, 'prototype': proto}

    def freeze_for_ca(self):
        for p in self.parameters(): p.requires_grad_(False)
        d = self.domains['CA']
        for module in (d.identity, d.output, d.cat_head, d.adapter_a, d.adapter_b, d.gate):
            for p in module.parameters(): p.requires_grad_(True)
        d.city_context.requires_grad_(True)
        d.missing_category.requires_grad_(True)


def sample_loss(model, city, sample, result, cfg):
    dev = result['logits'].device
    y = torch.tensor([sample['target']], device=dev)
    poi = F.cross_entropy(result['logits'][None, :], y)
    logdelta = torch.tensor(math.log(sample['delta']), device=dev)
    ls = result['logsigma']
    time = .5*(logdelta-result['mu']).square()*torch.exp(-2*ls)+ls
    cat = model.domains[city].categories[sample['target']]
    category = F.cross_entropy(result['category_logits'][None, :], cat[None]) if cat.item() > 0 else poi*0
    pg, ps = F.log_softmax(result['graph_logits'], -1), F.log_softmax(result['sequence_logits'], -1)
    consistency = .5*((pg.exp()*(pg-ps)).sum()+(ps.exp()*(ps-pg)).sum())
    if not model.cfg['time_head']: time = time*0
    return poi+cfg['time']*time+cfg['category']*category+cfg['consistency']*consistency


def bridge_loss(model, count=512):
    a, b = [model.prototypes(c)[1] for c in ('NYC', 'TKY')]
    if len(a) < 2 or len(b) < 2:
        return a.sum()*0
    aa = a[torch.randint(len(a), (count,), device=a.device)]
    bb = b[torch.randint(len(b), (count,), device=b.device)]
    def stats(x):
        mu = x.mean(0)
        z = x-mu
        cov = z.T @ z/(len(x)-1)+torch.eye(x.shape[-1], device=x.device)*1e-4
        return mu, cov
    ma, ca = stats(aa)
    mb, cb = stats(bb)
    return (ma-mb).square().sum()+(ca-cb).square().sum()
