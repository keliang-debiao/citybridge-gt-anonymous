"""Prespecified ablations and deterministic inference-time stress transformations."""
import copy
import math

import numpy as np

ABLATIONS = {
    'full': {},
    'without_prototype_space': {'representation': 'no_prototypes'},
    'without_evidence_gate': {'representation': 'fixed_gate'},
    'identity_only': {'representation': 'identity'},
    'prototype_only': {'representation': 'prototype'},
    'without_context': {'graph_attention': 'distance_no_context'},
    'standard_gat': {'graph_attention': 'gat'},
    'without_periodic': {'periodic': False},
    'local_only': {'periodic': False},
    'without_time_head': {'time_head': False},
    'without_reachability': {'reachability': False},
    'without_adapter': {'adapter': False},
    'without_bridge': {},
    'without_consistency': {},
    'without_category': {},
}


def ablation_config(config, name):
    if name not in ABLATIONS: raise ValueError('Unknown ablation')
    c = copy.deepcopy(config)
    c['model'].update(ABLATIONS[name])
    if name == 'without_bridge': c['loss']['bridge'] = 0.
    if name == 'without_consistency': c['loss']['consistency'] = 0.
    if name == 'without_category':
        c['loss']['category'] = 0.
        c['model']['lambda_category'] = 0.
    return c


def perturb_assets(assets, family, level, seed):
    """Training assets are frozen; return an independent inference-time view."""
    a = copy.deepcopy(assets)
    rng = np.random.default_rng(seed)
    if family == 'transition_deletion':
        drop = {(i, j) for i, j, _ in a['transitions'] if rng.random() < level}
        a['edges'] = [e for e in a['edges'] if not (e[2] == 0 and (e[0], e[1]) in drop)]
        a['transitions'] = [t for t in a['transitions'] if (t[0], t[1]) not in drop]
    elif family == 'category_masking':
        masked = {i for i in range(len(a['pois'])) if rng.random() < level}
        for i in masked: a['categories'][i] = ''; a['parents'][i] = ''; a['evidence'][i][3] = 0.
        a['edges'] = [e for e in a['edges'] if not (e[2] == 3 and (e[0] in masked or e[1] in masked))]
    elif family == 'coordinate_noise':
        # Isotropic Gaussian with component SD=level meters, not fixed-radius noise.
        coords = np.asarray(a['coords'], dtype=float)
        noise = rng.normal(0, level, size=coords.shape)
        coords[:, 0] += noise[:, 0]/111320.
        coords[:, 1] += noise[:, 1]/(111320*np.cos(np.radians(coords[:, 0])).clip(.01))
        a['coords'] = coords.tolist()
        norm = a['normalization']
        features = np.asarray(a['features'])
        features[:, :2] = (coords-np.asarray(norm['mean']))/np.asarray(norm['std'])
        a['features'] = features.tolist()
        # Neighbor topology remains fixed; this is an inference-channel stress test.
    else: raise ValueError('Unsupported asset perturbation')
    return a


def perturb_sample(sample, family, level, seed):
    s = copy.deepcopy(sample)
    rng = np.random.default_rng(seed)
    if family == 'timestamp_noise':
        t = np.asarray(s['times'], dtype=float)+rng.normal(0, level/60., len(s['times']))
        # Preserve observed event order. This is a documented reference convention.
        t = np.maximum.accumulate(t)
        diff = t-np.asarray(s['times'])
        s['times'] = t.tolist()
        s['elapsed'] = [0.] + np.diff(t).tolist()
        # Shift local hour/day consistently using original local week position.
        local_hours = np.asarray(s['weekdays'])*24+np.asarray(s['hours'])+diff
        s['hours'] = (np.floor(local_hours).astype(int) % 24).tolist()
        s['weekdays'] = (np.floor(local_hours/24).astype(int) % 7).tolist()
    elif family == 'coordinate_noise':
        lat, lon = s['current_coord']
        dx, dy = rng.normal(0, level, 2)
        s['current_coord'] = [lat+dx/111320, lon+dy/(111320*max(math.cos(math.radians(lat)), .01))]
    else: raise ValueError('Unsupported sample perturbation')
    return s
