import csv
import copy
import json
from datetime import datetime, timezone, timedelta
from pathlib import Path

import numpy as np

from .convert import FIELDS
from .data import prepare
from .engine import train_run, evaluate, calibrate
from .baseline import run_baseline
from .statistics import aggregate
from .util import dump


def make_toy(directory, users=8, events=80, pois=12, seed=17):
    """Unrelated synthetic trajectories, never tuned to manuscript performance."""
    out = Path(directory); out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    for city, base in [('NYC', (40.75, -73.98)), ('TKY', (35.68, 139.75)), ('CA', (37.77, -122.42))]:
        with open(out/f'{city}.csv', 'w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=FIELDS); w.writeheader()
            for u in range(users):
                t = datetime(2012, 1, 1, tzinfo=timezone.utc)+timedelta(minutes=u)
                for i in range(events):
                    # Some daily repetitions and random excursions, no real traces.
                    p = (i+u)%pois if rng.random() < .8 else int(rng.integers(pois))
                    t += timedelta(hours=1 if i%9 else 14)
                    w.writerow(dict(zip(FIELDS, [f'visitor{u}', f'place{p}', t.isoformat(),
                        base[0]+p*.002, base[1]+(p%4)*.002, 0,
                        '' if city == 'CA' else f'category{p%3}',
                        '' if city == 'CA' else f'parent{p%2}'])))
    dump(out/'SYNTHETIC_DATA.json', {'synthetic_data': True, 'seed': seed,
                                    'not_empirical_evidence': True, 'users': users, 'events_per_user': events})


def demo_config(config):
    c = copy.deepcopy(config)
    c['synthetic'] = True
    c['model'].update(hidden=16, category_dim=4, time_dim=4, prototypes=8, graph_layers=1,
        trajectory_layers=1, heads=2, feedforward=32, adapter_rank=2, max_length=12, dropout=.0)
    c['training'].update(batch_size=16, epochs=2, patience=2, device='cpu')
    c['loss']['bridge_batch'] = 16
    c['preprocessing'].update(min_source=2, min_ca=2, max_length=12)
    return c


def smoke(root, cfg):
    root = Path(root)
    if root.exists(): raise FileExistsError('Smoke output exists')
    c = demo_config(cfg)
    make_toy(root/'raw')
    for city in ['NYC', 'TKY', 'CA']:
        prepare(root/'raw'/f'{city}.csv', root/'prepared'/city/'fold1', 1, c['preprocessing'], city, True)
    source, ca = root/'runs'/'source', root/'runs'/'ca'
    train_run(root/'prepared', source, 1, 2026, c)
    train_run(root/'prepared', ca, 1, 2026, c, 'ca', source/'best.pt')
    dirs = []
    for city, checkpoint in [('NYC', source/'best.pt'), ('TKY', source/'best.pt'), ('CA', ca/'best.pt')]:
        vd, td = root/'predictions'/city/'val', root/'predictions'/city/'test'
        evaluate(root/'prepared', checkpoint, vd, city, 'val')
        evaluate(root/'prepared', checkpoint, td, city, 'test')
        calibrate(vd, td, root/'calibration'/f'{city}.json')
        run_baseline(root/'prepared', root/'baseline'/city, city, 1)
        dirs.append(td)
    aggregate(dirs, root/'smoke_summary.json', allow_synthetic=True)
    return root/'smoke_summary.json'


def simulated_logs(out, seeds=range(2026, 2031), folds=range(1, 6)):
    """Deliberately fictional formatting examples; NOT results or actual execution."""
    out = Path(out); out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(314159)
    for city in ['NYC', 'TKY', 'CA']:
        for f in folds:
            for s in seeds:
                rows = []
                for e in range(1, 5):
                    rows.append({'status': 'SIMULATED_EXAMPLE_NOT_AN_EXPERIMENT',
                        'is_simulated_log': True, 'synthetic_data': True,
                        'paper_result_reproduction_verified': False, 'city': city,
                        'fold': f, 'seed': s, 'epoch': e,
                        'illustrative_loss': round(float(4.0-e*.15+rng.normal(0, .02)), 5),
                        'illustrative_validation_acc5': round(float(.15+.03*e+rng.normal(0, .003)), 5),
                        'illustrative_duration_seconds': round(float(1+rng.random()), 4)})
                p = out/f'{city}_fold{f}_seed{s}.SIMULATED.jsonl'
                p.write_text(''.join(json.dumps(row)+'\n' for row in rows))
    dump(out/'SIMULATED_LOGS_MANIFEST.json', {'is_simulated_log': True,
         'purpose': 'AI experiment instruction and parser demonstration only',
         'forbidden_as_empirical_evidence': True, 'fictional_runs': 75,
         'generator_seed': 314159, 'not_matched_to_paper_results': True})
