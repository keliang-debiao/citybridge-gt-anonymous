"""Transparent sanity baselines. These are NOT substitutes for CAGNN/BiGSL/etc."""
from pathlib import Path

import numpy as np

from .engine import read
from .metrics import ranks, ranking_metrics
from .util import dump, sha, digest


def run_baseline(work, out, city, fold, seed=2026, method='markov'):
    out = Path(out)
    if out.exists(): raise FileExistsError('Baseline output exists')
    root = Path(work)/city/f'fold{fold}'
    a = read(root/'assets.json')
    samples = read(root/'test.json')
    n = len(a['pois'])
    freq = np.expm1(np.asarray(a['evidence'])[:, 0])
    transition = {(i, j): c for i, j, c in a['transitions']}
    rows = []
    for s in samples:
        logits = np.log(freq+1.)
        if method == 'markov':
            counts = np.array([transition.get((s['pois'][-1], j), 0) for j in range(n)])
            if counts.sum(): logits = np.log(counts+1e-8)
        elif method != 'popularity': raise ValueError('Unknown sanity baseline')
        r = int(ranks(logits[None, :], [s['target']])[0])
        rows.append({k: s[k] for k in ['event', 'user', 'activity', 'poi_group', 'length_group']} |
                    {'rank': r, 'target': s['target']})
    out.mkdir(parents=True)
    dump(out/'predictions.json', rows)
    dump(out/'metadata.json', {'city': city, 'fold': fold, 'seed': seed, 'split': 'test',
         'synthetic_data': a['synthetic'], 'is_simulated_log': False, 'method': method,
         'sample_sha256': sha(root/'test.json'), 'candidate_sha256': digest(a['pois']),
         'candidate_count': n, 'metrics': ranking_metrics([r['rank'] for r in rows])})
