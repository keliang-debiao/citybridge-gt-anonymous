"""Paired visitor-cluster inference from aligned per-event predictions, not paper tables."""
from pathlib import Path

import numpy as np

from .engine import read
from .metrics import per_event, ranking_metrics
from .util import dump, digest


def aggregate(directories, out, allow_synthetic=False):
    groups = {}
    for directory in directories:
        root = Path(directory)
        meta = read(root/'metadata.json')
        if meta['is_simulated_log'] or (meta['synthetic_data'] and not allow_synthetic):
            raise ValueError('Main tables reject simulated logs and synthetic-data runs')
        if meta['split'] != 'test': raise ValueError('Main results require test predictions')
        if not meta.get('valid_for_primary_reporting', True):
            raise ValueError('Perturbation/oracle outputs cannot enter primary result tables')
        bucket = groups.setdefault(meta['city'], {}).setdefault(meta['fold'], {})
        if meta['seed'] in bucket: raise ValueError('Duplicate dataset-fold-seed result')
        bucket[meta['seed']] = meta['metrics']
    result = {'synthetic_outputs': bool(allow_synthetic), 'aggregation': 'seed mean within fold; equal-weight fold mean and sample SD', 'datasets': {}}
    for city, folds in groups.items():
        if not allow_synthetic and set(folds) != set(range(1, 6)):
            raise ValueError('Main tables require all five folds')
        expected = {2026, 2027, 2028, 2029, 2030}
        if not allow_synthetic and any(set(seeds) != expected for seeds in folds.values()):
            raise ValueError('Main tables require the five prespecified seeds')
        per_fold = {str(f): {metric: float(np.mean([v[metric] for v in seeds.values()]))
                    for metric in next(iter(seeds.values()))} for f, seeds in sorted(folds.items())}
        keys = next(iter(per_fold.values()))
        result['datasets'][city] = {'folds': per_fold, 'summary': {
            k: {'mean': float(np.mean([v[k] for v in per_fold.values()])),
                'sd_across_folds': float(np.std([v[k] for v in per_fold.values()], ddof=1)) if len(per_fold)>1 else None}
            for k in keys}}
    dump(out, result)
    return result


def paired_inference(a_dirs, b_dirs, metric='acc5', subgroup=None, repeats=10000, seed=42, allow_synthetic=False):
    if len(a_dirs) != len(b_dirs): raise ValueError('Unequal numbers of runs')
    records, seeds, folds = [], set(), set()
    seen_runs = set()
    for a, b in zip(a_dirs, b_dirs):
        am, bm = [read(Path(d)/'metadata.json') for d in (a, b)]
        for m in (am, bm):
            if m['is_simulated_log'] or (m['synthetic_data'] and not allow_synthetic):
                raise ValueError('Inference rejects simulated logs and synthetic data by default')
        for k in ['city', 'fold', 'seed', 'split', 'sample_sha256', 'candidate_sha256', 'synthetic_data']:
            if am[k] != bm[k]: raise ValueError(f'Pairing mismatch {k}')
        if am['split'] != 'test': raise ValueError('Inference requires test predictions')
        run = (am['fold'], am['seed'])
        if run in seen_runs: raise ValueError('Duplicate paired run')
        seen_runs.add(run)
        aa, bb = [read(Path(d)/'predictions.json') for d in (a, b)]
        a_map, b_map = {r['event']: r for r in aa}, {r['event']: r for r in bb}
        if len(a_map) != len(aa) or len(b_map) != len(bb) or a_map.keys() != b_map.keys():
            raise ValueError('Paired predictions require unique identical event IDs')
        selected = []
        for key, x in a_map.items():
            y = b_map[key]
            if x['user'] != y['user'] or x['target'] != y['target']: raise ValueError('Identity/target mismatch')
            if subgroup and x[subgroup[0]] != subgroup[1]: continue
            diff = float(per_event([x['rank']])[metric][0]-per_event([y['rank']])[metric][0])
            selected.append((am['seed'], am['fold'], x['user'], diff))
        if not selected: raise ValueError('Empty subgroup')
        records.extend(selected)
        seeds.add(am['seed']); folds.add(am['fold'])
    seeds, folds = sorted(seeds), sorted(folds)
    if not allow_synthetic and (set(seeds) != set(range(2026, 2031)) or set(folds) != set(range(1, 6))):
        raise ValueError('Paper inference requires the complete five-seed five-fold grid')
    if seen_runs != {(f, s) for f in folds for s in seeds}: raise ValueError('Incomplete seed/fold grid')
    users = sorted({r[2] for r in records})
    ui = {u: i for i, u in enumerate(users)}
    si, fi = {s: i for i, s in enumerate(seeds)}, {f: i for i, f in enumerate(folds)}
    sums = np.zeros((len(seeds), len(folds), len(users)))
    counts = np.zeros_like(sums)
    for s, f, u, d in records:
        ix = (si[s], fi[f], ui[u])
        sums[ix] += d; counts[ix] += 1
    original = float((sums.sum(-1)/counts.sum(-1)).mean())
    rng = np.random.default_rng(seed)
    effects = []
    for _ in range(repeats):
        picked = rng.integers(len(seeds), size=len(seeds))
        values = []
        for s in picked:
            present = np.flatnonzero(counts[s].sum(0) > 0)
            for retry in range(100):
                u = rng.choice(present, size=len(present), replace=True)
                den = counts[s][:, u].sum(-1)
                if np.all(den): break
            else: raise ValueError('Insufficient visitor clusters for bootstrap')
            values.append(sums[s][:, u].sum(-1)/den)
        effects.append(float(np.asarray(values).mean()))
    lo, hi = np.quantile(effects, [.025, .975])
    # One sign per visitor across ALL folds and seeds preserves repeated-user dependence.
    contributions = (sums/counts.sum(-1, keepdims=True)).mean((0, 1))
    extreme = 0
    for _ in range(repeats):
        null = float((rng.choice([-1, 1], len(users))*contributions).sum())
        extreme += abs(null) >= abs(original)-1e-14
    return {'metric': metric, 'subgroup': subgroup, 'difference': original,
            'hierarchical_ci95': [float(lo), float(hi)],
            'p_raw': (extreme+1)/(repeats+1), 'repeats': repeats,
            'bootstrap_seed': seed, 'visitors': len(users), 'folds': folds, 'seeds': seeds,
            'synthetic_outputs': allow_synthetic, 'is_simulated_log': False,
            'estimand': 'mean over folds after seed averaging of event-weighted metric',
            'cluster': 'visitor retained across folds; seed sampled first'}


def holm(values):
    p = np.asarray(values, dtype=float)
    if np.any((p < 0) | (p > 1)): raise ValueError('p-values outside [0,1]')
    order = np.argsort(p, kind='stable')
    adj = np.minimum(1, np.maximum.accumulate(p[order]*(len(p)-np.arange(len(p)))))
    out = np.empty_like(p); out[order] = adj
    return out.tolist()
