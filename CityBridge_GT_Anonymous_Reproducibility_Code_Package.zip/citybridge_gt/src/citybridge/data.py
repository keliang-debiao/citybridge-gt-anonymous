"""Causal event splitting and train-only fitting. No model code needs test targets."""
import csv
import hashlib
import json
import math
from collections import Counter, defaultdict
from datetime import datetime, timezone, timedelta
from pathlib import Path

import numpy as np

from .util import dump, sha, digest

REQUIRED = ['user_id', 'poi_id', 'timestamp', 'latitude', 'longitude']


def read_events(path):
    events, rejected, seen = [], 0, set()
    with open(path, encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        if not set(REQUIRED).issubset(reader.fieldnames or []):
            raise ValueError('Required CSV columns: ' + ','.join(REQUIRED))
        for row in reader:
            try:
                u, p = row['user_id'].strip(), row['poi_id'].strip()
                if not u or not p:
                    raise ValueError('empty ID')
                dt = datetime.fromisoformat(row['timestamp'].replace('Z', '+00:00'))
                if dt.utcoffset() is None:
                    raise ValueError('Timestamp must include UTC offset')
                t = dt.timestamp()
                lat, lon = float(row['latitude']), float(row['longitude'])
                if not (math.isfinite(t) and -90 <= lat <= 90 and -180 <= lon <= 180):
                    raise ValueError('invalid coordinates/time')
                offset = int(row.get('offset_minutes', '') or dt.utcoffset().total_seconds()/60)
                if not -840 <= offset <= 840:
                    raise ValueError('invalid timezone offset')
                c, parent = row.get('category_id', '').strip(), row.get('category_parent', '').strip()
                key = (u, p, t, lat, lon, c, parent, offset)
                if key in seen:
                    continue
                seen.add(key)
                eid = digest(key)[:24]
                events.append({'u': u, 'p': p, 't': t, 'lat': lat, 'lon': lon,
                               'cat': c, 'parent': parent, 'offset': offset, 'id': eid})
            except (ValueError, KeyError, OverflowError):
                rejected += 1
    events.sort(key=lambda x: (x['u'], x['t'], x['id']))
    if not events:
        raise ValueError('No valid check-ins')
    return events, rejected


def time_fields(e):
    d = datetime.fromtimestamp(e['t'] + e['offset'] * 60, timezone.utc)
    return d.hour, d.weekday()


def enumerate_instances(events, session_hours=12, max_length=50):
    by_user = defaultdict(list)
    for e in events:
        by_user[e['u']].append(e)
    samples = []
    for u, es in sorted(by_user.items()):
        session = []
        for e in es:
            if session and (e['t']-session[-1]['t'])/3600 > session_hours:
                session = []
            if session:
                # Prefix windows contain only strictly earlier timestamps. Ties remain
                # deterministically sorted but do not produce ambiguous simultaneous targets.
                earlier = [x for x in session if x['t'] < e['t']]
                if earlier:
                    samples.append({'user': u, 'target': e, 'prefix': earlier[-max_length:],
                                    'observed_length': len(earlier), 'session_id': session[0]['id']})
            session.append(e)
    return samples


def split_instances(samples, fold):
    if fold not in range(1, 6):
        raise ValueError('fold must be 1..5')
    groups = defaultdict(list)
    for x in samples:
        groups[x['user']].append(x)
    out = {'train': [], 'val': [], 'test': []}
    for u, xs in sorted(groups.items()):
        xs.sort(key=lambda s: (s['target']['t'], s['target']['id']))
        n = len(xs)
        # Explicit rounding convention, unspecified in paper.
        a, b, c = [n * j // 10 for j in (fold + 3, fold + 4, fold + 5)]
        for name, lo, hi in [('train', 0, a), ('val', a, b), ('test', b, c)]:
            out[name].extend(xs[lo:hi])
    return out


def fit_training(raw_train, minimum):
    ev = {e['id']: e for s in raw_train for e in [*s['prefix'], s['target']]}
    while True:
        uc, pc = Counter(e['u'] for e in ev.values()), Counter(e['p'] for e in ev.values())
        nxt = {i: e for i, e in ev.items() if uc[e['u']] >= minimum and pc[e['p']] >= minimum}
        if len(nxt) == len(ev):
            break
        ev = nxt
    if not ev:
        raise ValueError('Empty training k-core; check dataset or lower threshold only for demo')
    return ev


def haversine(a, b):
    a, b = np.radians(np.asarray(a)), np.radians(np.asarray(b))
    d = b-a
    v = np.sin(d[..., 0]/2)**2 + np.cos(a[..., 0])*np.cos(b[..., 0])*np.sin(d[..., 1]/2)**2
    return 6371.0088 * 2 * np.arcsin(np.sqrt(np.clip(v, 0, 1)))


def build_assets(train_events, raw_train, cfg, category_free=False):
    es = list(train_events.values())
    pois = sorted(set(e['p'] for e in es))
    pm = {p: i for i, p in enumerate(pois)}
    n = len(pois)
    coords, weekly = np.zeros((n, 2)), np.zeros((n, 168))
    freq = np.zeros(n)
    cats, parents = [], []
    observations = defaultdict(list)
    for e in es: observations[e['p']].append(e)
    for p in pois:
        obs = observations[p]
        i = pm[p]
        coords[i] = np.mean([[e['lat'], e['lon']] for e in obs], axis=0)
        cats.append('' if category_free else Counter(e['cat'] for e in obs).most_common(1)[0][0])
        parents.append('' if category_free else Counter(e['parent'] for e in obs).most_common(1)[0][0])
        freq[i] = len(obs)
        for e in obs:
            h, w = time_fields(e)
            weekly[i, w*24+h] += 1
    weekly /= np.maximum(weekly.sum(1, keepdims=True), 1)
    mean = coords.mean(0)
    std = np.maximum(coords.std(0), 1e-6)
    features = np.concatenate([(coords-mean)/std, weekly, np.log1p(freq[:, None])], 1)
    # Iterate ORIGINAL immediately consecutive events; never bridge removed POIs.
    pairs = {}
    for s in raw_train:
        seq = s['prefix'] + [s['target']]
        for a, b in zip(seq, seq[1:]):
            if a['id'] in train_events and b['id'] in train_events:
                pairs[(a['id'], b['id'])] = (a, b)
    trans = defaultdict(list)
    for a, b in pairs.values():
        trans[(pm[a['p']], pm[b['p']])].append((a, b))
    edges, transition_counts = [], []
    outgoing = Counter()
    for (i, j), v in trans.items():
        outgoing[i] += len(v)
    def edge(i, j, relation, weight, phi=None, mask=None):
        edges.append([i, j, relation, float(weight),
                      [0.0]*34 if phi is None else list(map(float, phi)),
                      [0.0]*34 if mask is None else list(map(float, mask))])
    for (i, j), v in sorted(trans.items()):
        count = len(v)
        hours, days = np.zeros(24), np.zeros(7)
        for a, b in v:
            h, w = time_fields(b)
            hours[h] += 1
            days[w] += 1
        dt = np.mean([(b['t']-a['t'])/3600 for a, b in v])
        phi = [np.log1p(count), np.log1p(dt), np.log1p(haversine(coords[i], coords[j])),
               *(hours/count), *(days/count)]
        edge(i, j, 0, count/(outgoing[i]+1e-8), phi, np.ones(34))
        transition_counts.append([i, j, count])
    # Exact kNN via BallTree avoids allocating an N x N geographic matrix.
    from scipy.spatial import cKDTree
    rad = np.radians(coords)
    xyz = np.column_stack([np.cos(rad[:, 0])*np.cos(rad[:, 1]),
                           np.cos(rad[:, 0])*np.sin(rad[:, 1]), np.sin(rad[:, 0])])
    k = min(cfg['geo_neighbors'], n-1)
    geo_pairs = []
    if k:
        _, idx = cKDTree(xyz).query(xyz, k=min(k+1, n))
        for i, ns in enumerate(idx):
            for j in [int(j) for j in ns if j != i][:k]:
                geo_pairs.append((i, j, float(haversine(coords[i], coords[j]))))
    sigma = max(float(np.median([d for _, _, d in geo_pairs])) if geo_pairs else 1., 1e-6)
    for i, j, d in geo_pairs:
        phi, mask = np.zeros(34), np.zeros(34)
        phi[2], mask[2] = np.log1p(d), 1
        edge(i, j, 1, np.exp(-d/sigma), phi, mask)
    unit = weekly/np.maximum(np.linalg.norm(weekly, axis=1, keepdims=True), 1e-12)
    for lo in range(0, n, 256):
        sim = unit[lo:lo+256] @ unit.T
        for ii, row in enumerate(sim):
            i = lo+ii
            row[i] = -np.inf
            # Stable sort resolves equal similarities by POI index.
            for j in np.argsort(-row, kind='stable')[:cfg['periodic_neighbors']]:
                if row[j] >= cfg['periodic_threshold']:
                    edge(i, int(j), 2, row[j])
    if not category_free:
        fine, parent_groups = defaultdict(set), defaultdict(set)
        for i in range(n):
            if cats[i]: fine[cats[i]].add(i)
            if parents[i]: parent_groups[parents[i]].add(i)
        for i in range(n):
            ns = fine[cats[i]] | parent_groups[parents[i]]
            for j in sorted(ns - {i}):
                edge(i, j, 3, 1.)
    # Self relation prevents empty-neighborhood attention, explicitly documented.
    for i in range(n): edge(i, i, 4, 1.)
    indeg, outdeg = np.zeros(n), np.zeros(n)
    for i, j in trans:
        outdeg[i] += 1
        indeg[j] += 1
    evidence = np.column_stack([np.log1p(freq), np.log1p(indeg), np.log1p(outdeg),
                                [bool(c) for c in cats]])
    user_sessions = defaultdict(set)
    for s in raw_train:
        if s['target']['id'] in train_events:
            user_sessions[s['user']].add(s['session_id'])
    user_counts = {u: len(v) for u, v in user_sessions.items()}
    us = sorted(user_counts, key=lambda u: (user_counts[u], u))
    cutoff = int(len(us)*.15)
    activity = {u: ('inactive' if i < cutoff else 'active' if i >= len(us)-cutoff else 'normal')
                for i, u in enumerate(us)}
    # POI strata cutoffs are absent in manuscript: use explicit 20/30/50% rank groups.
    order = np.argsort(-freq, kind='stable')
    strata = ['tail']*n
    for rank, i in enumerate(order):
        strata[int(i)] = 'head' if rank < math.ceil(.2*n) else 'middle' if rank < math.ceil(.5*n) else 'tail'
    return {'pois': pois, 'coords': coords.tolist(), 'features': features.tolist(),
            'categories': cats, 'parents': parents, 'evidence': evidence.tolist(),
            'edges': edges, 'transitions': transition_counts,
            'normalization': {'mean': mean.tolist(), 'std': std.tolist()},
            'activity': activity, 'strata': strata, 'category_free': category_free,
            'train_event_ids': sorted(train_events),
            'transition_event_pairs': sorted([list(p) for p in pairs]),
            'geo_sigma_km': sigma}


def encode_split(samples, assets):
    pm = {p: i for i, p in enumerate(assets['pois'])}
    users = assets['activity']
    rows, unseen, excluded_user = [], 0, 0
    for s in samples:
        y = s['target']
        if y['u'] not in users:
            excluded_user += 1
            continue
        if y['p'] not in pm:
            unseen += 1
            continue
        pref = s['prefix']
        row = {'event': y['id'], 'user': digest(s['user'])[:20],
               'pois': [pm.get(e['p'], len(pm)) for e in pref],
               'hours': [time_fields(e)[0] for e in pref],
               'weekdays': [time_fields(e)[1] for e in pref],
               'times': [e['t']/3600 for e in pref],
               'elapsed': [0.] + [(b['t']-a['t'])/3600 for a, b in zip(pref, pref[1:])],
               'current_coord': [pref[-1]['lat'], pref[-1]['lon']],
               'target': pm[y['p']], 'delta': max((y['t']-pref[-1]['t'])/3600, 1e-6),
               'activity': users[y['u']], 'poi_group': assets['strata'][pm[y['p']]],
               'length_group': '2-5' if s['observed_length']+1 <= 5 else '6-15' if s['observed_length']+1 <= 15 else '16-50'}
        # Session stratum uses OBSERVED prefix+one target, never future session length.
        rows.append(row)
    total = len(samples)
    return rows, {'eligible_targets': total, 'retained_targets': len(rows),
                  'excluded_users': excluded_user, 'unseen_poi_targets': unseen,
                  'overall_coverage': len(rows)/total if total else 0.,
                  'known_user_poi_coverage': len(rows)/max(total-excluded_user, 1)}


def prepare(csv_path, out, fold, cfg, domain, synthetic=False):
    out = Path(out)
    if out.exists() and any(out.iterdir()):
        raise FileExistsError(f'Refusing to overwrite prepared directory: {out}')
    events, rejected = read_events(csv_path)
    samples = enumerate_instances(events, cfg['session_hours'], cfg['max_length'])
    splits = split_instances(samples, fold)
    minimum = cfg['min_ca'] if domain == 'CA' else cfg['min_source']
    train = fit_training(splits['train'], minimum)
    assets = build_assets(train, splits['train'], cfg, cfg.get('disable_categories', False) or (domain == 'CA' and cfg['category_free_ca']))
    assets['domain'], assets['fold'], assets['synthetic'] = domain, fold, synthetic
    counts, ids = {}, {}
    for name, ss in splits.items():
        rows, counts[name] = encode_split(ss, assets)
        if not rows:
            raise ValueError(f'Empty {name} after training-only filtering')
        ids[name] = [r['event'] for r in rows]
        dump(out / f'{name}.json', rows)
    # No raw user names or POI labels in exported graph artifacts.
    assets['activity'] = {digest(u)[:20]: g for u, g in assets['activity'].items()}
    assets['pois'] = [digest(p)[:20] for p in assets['pois']]
    dump(out / 'assets.json', assets)
    audit = {'schema_version': 1, 'domain': domain, 'fold': fold, 'synthetic': synthetic,
             'input_sha256': sha(csv_path), 'preprocessing': cfg, 'rejected_rows': rejected,
             'counts': counts, 'target_ids': ids, 'assets_sha256': sha(out/'assets.json'),
             'disjoint_target_partitions': all(not set(ids[a]) & set(ids[b])
                    for a, b in [('train', 'val'), ('train', 'test'), ('val', 'test')]),
             'transition_provenance_train_only': all(a in train and b in train for a, b in assets['transition_event_pairs']),
             'category_parent_available': bool(any(assets['parents'])),
             'visitor_relative_not_global_calendar_split': True}
    dump(out / 'audit.json', audit)
    assert audit['disjoint_target_partitions'] and audit['transition_provenance_train_only']
    return audit
