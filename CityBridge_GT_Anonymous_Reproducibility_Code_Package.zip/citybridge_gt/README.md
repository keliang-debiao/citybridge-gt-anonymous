# CityBridge-GT anonymous reference repository

Manuscript-derived PyTorch reference implementation of **CityBridge-GT: A Leakage-Controlled Dual-Space Graph Transformer for Cross-City Next-POI Prediction in Smart Tourism**.

**Status:** runnable reference code with actual synthetic-data smoke evidence. This is a new implementation reconstructed from the supplied manuscript. It is not the unavailable original research repository, and it has not reproduced the manuscript's empirical results. The archive is structured for anonymous review; submission as a verified reproduction requires the evidence described in `docs/REPRODUCIBILITY_STATUS.md`.

## Start here

- Chinese experiment instructions and AI handoff: [`docs/AI_EXPERIMENT_GUIDE_ZH.md`](docs/AI_EXPERIMENT_GUIDE_ZH.md).
- Exact scope, missing inputs and evidence: [`docs/REPRODUCIBILITY_STATUS.md`](docs/REPRODUCIBILITY_STATUS.md).
- Architecture and manuscript mapping: [`docs/PAPER_CODE_MAP.md`](docs/PAPER_CODE_MAP.md).
- Explicit implementation choices: [`docs/IMPLEMENTATION_DECISIONS.md`](docs/IMPLEMENTATION_DECISIONS.md).
- Raw data contracts: [`docs/DATA.md`](docs/DATA.md).

## Install

Python 3.11 or 3.12. The supplied CPU tests use PyTorch 2.5.1; see `evidence/verification_environment.json` for the environment actually tested. GPU training needs the appropriate PyTorch 2.5.1 CUDA build for your driver.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install torch==2.5.1 --index-url https://download.pytorch.org/whl/cpu
python -m pip install -r requirements.txt
python -m pip install --no-deps -e .
python -m unittest discover -s tests -v
python -m citybridge smoke --out work/my-smoke
```

Windows PowerShell activation: `.venv\Scripts\Activate.ps1`. All subsequent commands use Python and work without Bash. Dockerfile and optional CI configuration are provided; Docker and hosted CI have not been executed in this environment.

The smoke command creates three toy cities, prepares Fold 1, trains a reduced model for two epochs, adapts CA with frozen shared parameters, evaluates validation/test once, calibrates from validation logits, and runs a Markov sanity baseline. It does not download benchmarks. The command must use a fresh output directory.

## Real experiments

Obtain the original datasets and exact benchmark preprocessing artifacts described in `docs/DATA.md`. Create `data/canonical/NYC.csv`, `TKY.csv`, `CA.csv`. No real mobility records are bundled.

```bash
# Audit all folds before spending time on training.
python scripts/run_suite.py --raw data/canonical --out work/preflight --prepare-only
# Use another fresh directory to run the full five-fold five-seed suite.
python scripts/run_suite.py --raw data/canonical --out runs/full --config configs/paper.yaml
python scripts/export_tables.py --summary runs/full/results.json --out runs/full/main.csv
python scripts/plot_results.py --summary runs/full/results.json --out runs/full/folds.png
```

For CUDA, copy `configs/paper.yaml`, change `training.device` to `cuda`, and use the copy. Default CA is **category-free**, because SNAP does not provide semantic categories. A mapped-category CA result requires the exact external category mapping and its provenance; it must not be reconstructed from desired scores.

This exact-context reference implementation processes one full-graph query at a time and accumulates gradients to the specified optimizer batch size. It prioritizes explicit information boundaries; it does not establish the paper's GPU speed or parameter counts. Plan a small real-data trial before the full suite.

## Evidence categories

| Location | Content | Meaning |
|---|---|---|
| `examples/simulated_logs/` | 75 fictional JSONL traces | Demonstrates log format only; every row is labeled simulated |
| `evidence/actual_smoke/` | Actual toy-data execution, selected weights and logits | Verifies execution on synthetic data, not scientific performance |
| `assets/manuscript_reference_tables.json` | Transcribed paper values | Comparison targets only; never loaded by training/evaluation |
| Your `runs/` directory | Newly computed benchmark artifacts | Empirical evidence only after checking its provenance |

Main aggregation and statistical tests reject simulated logs and, by default, synthetic-data runs. No code fills missing measurements from manuscript tables.

## Contents

`src/citybridge/` contains preprocessing, graph construction, model, source training, external adaptation, full-vocabulary predictions, calibration, cluster inference, perturbations and transparent sanity baselines. `scripts/` contains full-suite execution, validation-only search, table/figure export, efficiency summarization and review checks. `tests/` covers causal input boundaries, transition deduplication, freeze masks and metric definitions.

The closest named baselines (CAGNN, BiGSL, City Matters and others) require separately verified official code; this repository does not relabel a generic implementation as those models. See `docs/BASELINES.md`.

## Anonymous review

No author names, affiliations, personal contact addresses, original document, raw private paths or Git history are included. Third-party datasets and methods retain their proper citations. Repository hosting, anonymous URL access and account identity must be reviewed separately; this archive does not publish or upload an external repository.

```bash
python scripts/anonymous_audit.py --root . --out work/anonymity_scan.json
python scripts/submission_gate.py --evidence private/verified_evidence --out work/submission_status.json
```

The gate intentionally remains unverified until real evidence is supplied and reviewed. A formatted code archive alone cannot prove the manuscript's results.

An additional complete **synthetic** five-fold five-seed execution is included under `evidence/full_suite_synthetic/`: 25 source fits, 25 CA fits and 75 test prediction sets. Reproduction commands appear in `docs/LOGS.md`. This verifies the orchestration on a tiny dataset, not the paper's empirical claims. `requirements-lock-cpu.txt` records the exact CPU dependencies used during local verification.
